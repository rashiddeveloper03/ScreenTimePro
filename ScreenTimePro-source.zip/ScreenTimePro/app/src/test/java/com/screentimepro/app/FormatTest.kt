package com.screentimepro.app

import com.screentimepro.app.ui.components.formatCountdown
import com.screentimepro.app.ui.components.formatDuration
import com.screentimepro.app.ui.components.timeOfDay
import org.junit.Assert.assertEquals
import org.junit.Test

class FormatTest {
    @Test
    fun countdownRoundsUp() {
        assertEquals("00:00", formatCountdown(0))
        assertEquals("00:01", formatCountdown(1))
        assertEquals("05:00", formatCountdown(5 * 60_000L))
        assertEquals("1:00:00", formatCountdown(3_600_000L))
        assertEquals("12:00:00", formatCountdown(12 * 3_600_000L))
    }

    @Test
    fun durations() {
        assertEquals("25m", formatDuration(25 * 60_000L))
        assertEquals("2h", formatDuration(2 * 3_600_000L))
        assertEquals("1h 30m", formatDuration(90 * 60_000L))
        assertEquals("45s", formatDuration(45_000L))
    }

    @Test
    fun timeFormats() {
        assertEquals("09:00", timeOfDay(9, 0, true))
        assertEquals("9:00 AM", timeOfDay(9, 0, false))
        assertEquals("11:30 PM", timeOfDay(23, 30, false))
    }
}
