package com.screentimepro.app

import com.screentimepro.app.alarm.ScheduleCalc
import com.screentimepro.app.data.Schedule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime

class ScheduleCalcTest {
    private val zone = ZoneId.of("Asia/Karachi")

    // Friday 16 Oct 2026, 08:00
    private val fridayMorning = ZonedDateTime.of(LocalDateTime.of(2026, 10, 16, 8, 0), zone)

    private fun schedule(h: Int, m: Int, dur: Int, days: Int = 0, epochDay: Long = 0) =
        Schedule(id = 1, name = "t", startHour = h, startMinute = m, durationMinutes = dur, repeatDays = days, oneTimeEpochDay = epochDay)

    @Test
    fun oneTimeInFuture() {
        val s = schedule(9, 0, 120, epochDay = LocalDate.of(2026, 10, 16).toEpochDay())
        val next = ScheduleCalc.nextStart(s, fridayMorning)
        assertEquals(ZonedDateTime.of(LocalDateTime.of(2026, 10, 16, 9, 0), zone), next)
    }

    @Test
    fun oneTimeInPastIsNull() {
        val s = schedule(7, 0, 30, epochDay = LocalDate.of(2026, 10, 16).toEpochDay())
        assertNull(ScheduleCalc.nextStart(s, fridayMorning))
    }

    @Test
    fun dailyLaterTodayOrTomorrow() {
        val s = schedule(9, 0, 60, days = Schedule.EVERY_DAY)
        assertEquals(16, ScheduleCalc.nextStart(s, fridayMorning)!!.dayOfMonth)
        val early = schedule(7, 0, 60, days = Schedule.EVERY_DAY)
        assertEquals(17, ScheduleCalc.nextStart(early, fridayMorning)!!.dayOfMonth)
    }

    @Test
    fun weekdaysSkipWeekend() {
        val s = schedule(7, 0, 60, days = Schedule.WEEKDAYS)
        val next = ScheduleCalc.nextStart(s, fridayMorning)!!
        assertEquals(DayOfWeek.MONDAY, next.dayOfWeek)
        assertEquals(19, next.dayOfMonth)
    }

    @Test
    fun noDaysSelectedRepeatsNever() {
        val s = schedule(9, 0, 60, days = 0, epochDay = 0)
        assertNull(ScheduleCalc.nextStart(s, fridayMorning))
    }

    @Test
    fun activeWindowDetected() {
        val s = schedule(7, 30, 60, days = Schedule.EVERY_DAY)
        val start = ScheduleCalc.activeWindowStart(s, fridayMorning)
        assertNotNull(start)
        assertEquals(ZonedDateTime.of(LocalDateTime.of(2026, 10, 16, 7, 30), zone).toInstant().toEpochMilli(), start)
        val ended = schedule(6, 0, 60, days = Schedule.EVERY_DAY)
        assertNull(ScheduleCalc.activeWindowStart(ended, fridayMorning))
    }

    @Test
    fun windowCrossingMidnightFromYesterday() {
        // Thursday 23:00 for 10 hours covers Friday 08:00
        val s = schedule(23, 0, 600, days = ScheduleCalc.dayBit(DayOfWeek.THURSDAY))
        assertNotNull(ScheduleCalc.activeWindowStart(s, fridayMorning))
    }

    @Test
    fun endTimeWrapsMidnight() {
        assertEquals(120, ScheduleCalc.minutesBetween(9, 0, 11, 0))
        assertEquals(180, ScheduleCalc.minutesBetween(22, 0, 1, 0))
        assertEquals(24 * 60, ScheduleCalc.minutesBetween(9, 0, 9, 0))
    }

    @Test
    fun timeZoneChangeKeepsLocalStartTime() {
        val s = schedule(9, 0, 60, days = Schedule.EVERY_DAY)
        val other = fridayMorning.withZoneSameInstant(ZoneId.of("Europe/London"))
        val next = ScheduleCalc.nextStart(s, other)!!
        assertEquals(9, next.hour)
        assertEquals(ZoneId.of("Europe/London"), next.zone)
    }
}
