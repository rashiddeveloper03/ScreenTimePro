package com.screentimepro.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.screentimepro.app.session.SessionManager
import com.screentimepro.app.session.SessionState
import com.screentimepro.app.session.SessionStatus
import com.screentimepro.app.ui.theme.LocalAppSettings
import com.screentimepro.app.ui.theme.TimerDigits

/** Big ring + countdown + controls for whatever session is active. */
@Composable
fun ActiveSessionPanel(
    state: SessionState,
    onFullscreen: () -> Unit,
    ringSize: Dp = 260.dp,
    subtitle: String? = null
) {
    val now = rememberNow()
    val remaining = remember(now, state) { SessionManager.remainingMs(state) }
    val progress = remember(now, state) { SessionManager.progress(state) }
    val use24h = LocalAppSettings.current.use24h
    val paused = state.status == SessionStatus.PAUSED

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        CountdownRing(progress = progress, paused = paused, modifier = Modifier.size(ringSize)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    state.type.title.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.5.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    formatCountdown(remaining),
                    style = TimerDigits.copy(fontSize = if (remaining >= 3_600_000) 46.sp else 58.sp),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    if (paused) "Paused" else "Ends ${timeOfDay(now + remaining, use24h)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(state.displayTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(16.dp))
        SessionControls(state = state, onFullscreen = onFullscreen)
    }
}

@Composable
fun SessionControls(state: SessionState, onFullscreen: () -> Unit) {
    val haptic = rememberHaptic(strong = true)
    var confirmStop by remember { mutableStateOf(false) }
    val paused = state.status == SessionStatus.PAUSED

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        FilledTonalIconButton(onClick = { haptic(); SessionManager.restart() }, modifier = Modifier.size(52.dp)) {
            Icon(Icons.Rounded.Replay, contentDescription = "Restart")
        }
        Button(
            onClick = { haptic(); if (paused) SessionManager.resume() else SessionManager.pause() },
            modifier = Modifier.height(56.dp).width(140.dp)
        ) {
            Icon(if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(if (paused) "Resume" else "Pause")
        }
        FilledTonalIconButton(onClick = { haptic(); confirmStop = true }, modifier = Modifier.size(52.dp)) {
            Icon(Icons.Rounded.Stop, contentDescription = "Stop")
        }
    }
    Spacer(Modifier.height(10.dp))
    FilledTonalButton(onClick = onFullscreen) {
        Icon(Icons.Rounded.Fullscreen, contentDescription = null)
        Spacer(Modifier.width(6.dp))
        Text("Full-screen clock")
    }

    if (confirmStop) {
        AlertDialog(
            onDismissRequest = { confirmStop = false },
            title = { Text("Stop session?") },
            text = { Text("The screen will be allowed to turn off normally. Time so far is saved to your history.") },
            confirmButton = {
                TextButton(onClick = { confirmStop = false; SessionManager.stop() }) { Text("Stop") }
            },
            dismissButton = { TextButton(onClick = { confirmStop = false }) { Text("Keep going") } }
        )
    }
}
