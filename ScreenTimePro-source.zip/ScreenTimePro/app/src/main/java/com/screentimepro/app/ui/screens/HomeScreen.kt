@file:OptIn(ExperimentalLayoutApi::class)

package com.screentimepro.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.screentimepro.app.alarm.AlarmScheduler
import com.screentimepro.app.data.WorkTask
import com.screentimepro.app.session.Notifications
import com.screentimepro.app.session.SessionManager
import com.screentimepro.app.session.SessionType
import com.screentimepro.app.ui.AppViewModel
import com.screentimepro.app.ui.Routes
import com.screentimepro.app.ui.components.ActiveSessionPanel
import com.screentimepro.app.ui.components.SectionCard
import com.screentimepro.app.ui.components.StatTile
import com.screentimepro.app.ui.components.amPm
import com.screentimepro.app.ui.components.clockDigits
import com.screentimepro.app.ui.components.formatDuration
import com.screentimepro.app.ui.components.formatMinutes
import com.screentimepro.app.ui.components.longDate
import com.screentimepro.app.ui.components.nextUpcoming
import com.screentimepro.app.ui.components.rememberHaptic
import com.screentimepro.app.ui.components.rememberNow
import com.screentimepro.app.ui.components.relativeDay
import com.screentimepro.app.ui.components.startOfToday
import com.screentimepro.app.ui.components.startsIn
import com.screentimepro.app.ui.components.timeOfDay
import com.screentimepro.app.ui.theme.LocalAppSettings
import com.screentimepro.app.ui.theme.clockStyle
import java.time.LocalDate

@Composable
fun HomeScreen(
    vm: AppViewModel,
    openClock: () -> Unit,
    navigate: (String) -> Unit,
    push: (String) -> Unit
) {
    val settings = LocalAppSettings.current
    val session by SessionManager.state.collectAsStateWithLifecycle()
    val schedules by vm.schedules.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val todos by vm.todos.collectAsStateWithLifecycle()
    val work by vm.workTasks.collectAsStateWithLifecycle()
    val now = rememberNow()
    val ctx = LocalContext.current
    val haptic = rememberHaptic(strong = true)

    var permTick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { permTick++ }
    val missingPerms = remember(permTick) {
        buildList {
            if (!Notifications.canPost(ctx)) add("notifications")
            if (!AlarmScheduler.canScheduleExact(ctx)) add("exact alarms")
            if (!Notifications.canUseFullScreen(ctx)) add("full-screen alerts")
        }
    }

    val todayStart = startOfToday()
    val today = sessions.filter { it.startedAt >= todayStart }
    val focusToday = today.filter { it.type == SessionType.FOCUS.name }
    val screenMsToday = today.sumOf { it.actualMs }
    val todayEpoch = LocalDate.now().toEpochDay()
    val dueToday = todos.count { !it.done && it.dueEpochDay in 1..todayEpoch } +
        work.count { it.status != WorkTask.COMPLETED && it.deadline in 1 until (todayStart + 86_400_000L) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
            Column(Modifier.weight(1f)) {
                Text("ScreenTime Pro", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    greeting(now),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { push(Routes.STATS) }) { Icon(Icons.Rounded.BarChart, contentDescription = "Statistics") }
            IconButton(onClick = { push(Routes.SETTINGS) }) { Icon(Icons.Rounded.Settings, contentDescription = "Settings") }
        }

        if (missingPerms.isNotEmpty()) {
            SectionCard(container = MaterialTheme.colorScheme.errorContainerSafe()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Schedules may not wake the screen", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Missing: ${missingPerms.joinToString()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { push(Routes.SETTINGS) }) { Text("Fix") }
                }
            }
        }

        // Live clock
        val style = clockStyle(settings.clockFont)
        SectionCard(modifier = Modifier.clickable { openClock() }) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    clockDigits(now, settings.use24h, settings.showSeconds),
                    fontFamily = style.family,
                    fontWeight = style.weight,
                    fontSize = 54.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (!settings.use24h) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        amPm(now),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
                Icon(
                    Icons.Rounded.Fullscreen,
                    contentDescription = "Full-screen clock",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }
            Text(longDate(now), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (session.isActive) {
            SectionCard(title = "Active session") {
                ActiveSessionPanel(state = session, onFullscreen = openClock, ringSize = 220.dp)
            }
        } else {
            SectionCard(title = "Quick start", action = {
                TextButton(onClick = { navigate(Routes.TIMER) }) { Text("Custom") }
            }) {
                Text(
                    "Keep the screen awake for…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(5, 15, 30, 60, 120).forEach { m ->
                        AssistChip(
                            onClick = {
                                haptic()
                                SessionManager.start(SessionType.TIMER, m * 60_000L, "Screen on · ${formatMinutes(m)}")
                            },
                            label = { Text(formatMinutes(m)) }
                        )
                    }
                }
            }
        }

        // Next schedule
        val upcoming = remember(schedules, now / 30_000) { nextUpcoming(schedules) }
        SectionCard(title = "Next scheduled session", action = {
            TextButton(onClick = { navigate(Routes.SCHEDULES) }) { Text("Manage") }
        }) {
            if (upcoming == null) {
                Text(
                    "No upcoming schedules. Add one to turn the screen on automatically at a set time.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Alarm, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(upcoming.schedule.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${relativeDay(upcoming.start)} · ${timeOfDay(upcoming.start.hour, upcoming.start.minute, settings.use24h)} · ${formatMinutes(upcoming.schedule.durationMinutes)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(startsIn(upcoming.start), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        // Today
        SectionCard(title = "Today", action = {
            TextButton(onClick = { push(Routes.STATS) }) { Text("History") }
        }) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(formatDuration(screenMsToday), "Screen-on time", Modifier.weight(1f))
                StatTile("${focusToday.count { it.completed }}/${settings.focusGoal}", "Focus goal", Modifier.weight(1f))
                StatTile("$dueToday", "Tasks due", Modifier.weight(1f), accent = MaterialTheme.colorScheme.tertiary)
            }
            Spacer(Modifier.height(12.dp))
            val goalProgress = (focusToday.count { it.completed }.toFloat() / settings.focusGoal.coerceAtLeast(1)).coerceIn(0f, 1f)
            LinearProgressIndicator(progress = { goalProgress }, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(8.dp))
    }
}

private fun greeting(now: Long): String {
    val h = java.time.Instant.ofEpochMilli(now).atZone(java.time.ZoneId.systemDefault()).hour
    return when (h) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Working late?"
    }
}

@Composable
private fun androidx.compose.material3.ColorScheme.errorContainerSafe() =
    error.copy(alpha = 0.12f)
