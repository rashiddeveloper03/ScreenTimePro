@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.screentimepro.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.screentimepro.app.data.WorkTask
import com.screentimepro.app.session.SessionManager
import com.screentimepro.app.session.SessionType
import com.screentimepro.app.ui.AppViewModel
import com.screentimepro.app.ui.components.ActiveSessionPanel
import com.screentimepro.app.ui.components.DurationPickerDialog
import com.screentimepro.app.ui.components.EmptyState
import com.screentimepro.app.ui.components.LinearGoal
import com.screentimepro.app.ui.components.SectionCard
import com.screentimepro.app.ui.components.StatTile
import com.screentimepro.app.ui.components.formatDuration
import com.screentimepro.app.ui.components.formatMinutes
import com.screentimepro.app.ui.components.rememberHaptic
import com.screentimepro.app.ui.components.shortDateTime
import com.screentimepro.app.ui.components.startOfToday
import com.screentimepro.app.ui.theme.LocalAppSettings

data class TaskLink(val id: Long, val kind: String, val title: String)

val FOCUS_PRESETS = listOf(25, 50, 90)

@Composable
fun FocusScreen(vm: AppViewModel, openClock: () -> Unit) {
    val session by SessionManager.state.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val todos by vm.todos.collectAsStateWithLifecycle()
    val work by vm.workTasks.collectAsStateWithLifecycle()
    val settings = LocalAppSettings.current
    val haptic = rememberHaptic(strong = true)

    var minutes by rememberSaveable { mutableIntStateOf(25) }
    var showCustom by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    var link by remember { mutableStateOf<TaskLink?>(null) }

    val focus = sessions.filter { it.type == SessionType.FOCUS.name }
    val todayStart = startOfToday()
    val today = focus.filter { it.startedAt >= todayStart }
    val completedToday = today.count { it.completed }
    val minutesToday = today.sumOf { it.actualMs } / 60_000

    val openTasks = remember(todos, work) {
        work.filter { it.status != WorkTask.COMPLETED }.map { TaskLink(it.id, "fiverr", "${it.title}${if (it.clientName.isNotBlank()) " · " + it.clientName else ""}") } +
            todos.filter { !it.done }.map { TaskLink(it.id, "todo", it.title) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Focus Mode", style = MaterialTheme.typography.headlineSmall)

        if (session.isActive) {
            SectionCard {
                ActiveSessionPanel(
                    state = session,
                    onFullscreen = openClock,
                    subtitle = if (session.taskId > 0) "Time is added to the linked task" else null
                )
            }
        } else {
            SectionCard(title = "Start a focus session") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FOCUS_PRESETS.forEach { m ->
                        val selected = minutes == m
                        Card(
                            onClick = { minutes = m },
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceContainerHighest
                            ),
                            border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
                        ) {
                            Column(
                                Modifier.fillMaxWidth().padding(vertical = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("$m", style = MaterialTheme.typography.headlineMedium)
                                Text("min", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { showCustom = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (minutes in FOCUS_PRESETS) "Custom duration" else "Custom: ${formatMinutes(minutes)}")
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().clickable { showPicker = true }.padding(vertical = 8.dp)
                ) {
                    Icon(Icons.Rounded.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        link?.title ?: "Link to a task (optional)",
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = if (link == null) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )
                    if (link != null) {
                        IconButton(onClick = { link = null }) { Icon(Icons.Rounded.Close, contentDescription = "Remove link") }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        haptic()
                        val l = link
                        SessionManager.start(
                            SessionType.FOCUS, minutes * 60_000L,
                            label = l?.title ?: "Focus · ${formatMinutes(minutes)}",
                            taskId = l?.id ?: 0, taskKind = l?.kind ?: ""
                        )
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Start focus · ${formatMinutes(minutes)}")
                }
            }
        }

        SectionCard(title = "Today's focus") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("$completedToday", "Completed", Modifier.weight(1f))
                StatTile("${minutesToday}m", "Focused", Modifier.weight(1f))
                StatTile("${settings.focusGoal}", "Daily goal", Modifier.weight(1f), accent = MaterialTheme.colorScheme.tertiary)
            }
            Spacer(Modifier.height(12.dp))
            LinearGoal(completedToday, settings.focusGoal)
        }

        SectionCard(title = "Recent focus sessions") {
            if (focus.isEmpty()) {
                EmptyState(Icons.Rounded.SelfImprovement, "No sessions yet", "Completed focus sessions appear here.")
            } else {
                focus.take(8).forEachIndexed { i, r ->
                    if (i > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 10.dp)) {
                        Icon(
                            if (r.completed) Icons.Rounded.CheckCircle else Icons.Rounded.Close,
                            contentDescription = if (r.completed) "Completed" else "Stopped early",
                            tint = if (r.completed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.label, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                shortDateTime(r.startedAt, settings.use24h),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(formatDuration(r.actualMs), style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }

    if (showCustom) {
        DurationPickerDialog(
            initialMinutes = minutes,
            maxHours = 12,
            title = "Custom focus",
            onDismiss = { showCustom = false },
            onConfirm = { minutes = it; showCustom = false }
        )
    }
    if (showPicker) {
        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("Link a task") },
            text = {
                if (openTasks.isEmpty()) {
                    Text("No open tasks. Add Fiverr orders or to-dos in the Work tab.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(openTasks, key = { it.kind + it.id }) { t ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { link = t; showPicker = false }
                                    .padding(vertical = 12.dp)
                            ) {
                                FilterChip(
                                    selected = false,
                                    onClick = { link = t; showPicker = false },
                                    label = { Text(if (t.kind == "fiverr") "Fiverr" else "To-do") }
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(t.title, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPicker = false }) { Text("Close") } }
        )
    }
}

/** Dialog used by task lists to start a focus session for one task. */
@Composable
fun FocusForTaskDialog(task: TaskLink, onDismiss: () -> Unit, onStarted: () -> Unit) {
    var minutes by remember { mutableIntStateOf(25) }
    var showCustom by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Focus on task") },
        text = {
            Column {
                Text(task.title, style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(12.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (FOCUS_PRESETS + listOf(15, 120)).sorted().forEach { m ->
                        FilterChip(selected = minutes == m, onClick = { minutes = m }, label = { Text(formatMinutes(m)) })
                    }
                    FilterChip(
                        selected = minutes !in (FOCUS_PRESETS + listOf(15, 120)),
                        onClick = { showCustom = true },
                        label = { Text("Custom") }
                    )
                }
                Text(
                    "Time spent is recorded on the task.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                SessionManager.start(SessionType.FOCUS, minutes * 60_000L, task.title, taskId = task.id, taskKind = task.kind)
                onStarted()
            }) { Text("Start ${formatMinutes(minutes)}") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
    if (showCustom) {
        DurationPickerDialog(
            initialMinutes = minutes, maxHours = 12, title = "Custom focus",
            onDismiss = { showCustom = false },
            onConfirm = { minutes = it; showCustom = false }
        )
    }
}
