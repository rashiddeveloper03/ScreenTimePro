package com.screentimepro.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.screentimepro.app.session.SessionManager
import com.screentimepro.app.session.SessionStatus
import com.screentimepro.app.ui.components.KeepScreenOnEffect
import com.screentimepro.app.ui.components.WindowBrightnessEffect
import com.screentimepro.app.ui.screens.FocusScreen
import com.screentimepro.app.ui.screens.HomeScreen
import com.screentimepro.app.ui.screens.SchedulesScreen
import com.screentimepro.app.ui.screens.SettingsScreen
import com.screentimepro.app.ui.screens.StatsScreen
import com.screentimepro.app.ui.screens.TimerScreen
import com.screentimepro.app.ui.screens.WorkScreen
import com.screentimepro.app.ui.theme.LocalAppSettings
import kotlinx.coroutines.delay

object Routes {
    const val HOME = "home"
    const val TIMER = "timer"
    const val FOCUS = "focus"
    const val SCHEDULES = "schedules"
    const val WORK = "work"
    const val STATS = "stats"
    const val SETTINGS = "settings"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab(Routes.HOME, "Home", Icons.Rounded.Home),
    Tab(Routes.TIMER, "Timer", Icons.Rounded.Timer),
    Tab(Routes.FOCUS, "Focus", Icons.Rounded.SelfImprovement),
    Tab(Routes.SCHEDULES, "Schedules", Icons.Rounded.Alarm),
    Tab(Routes.WORK, "Work", Icons.Rounded.Work)
)

@Composable
fun AppRoot(vm: AppViewModel, openClock: () -> Unit) {
    val session by SessionManager.state.collectAsStateWithLifecycle()
    val settings = LocalAppSettings.current
    KeepScreenOnEffect(session.status == SessionStatus.RUNNING)
    WindowBrightnessEffect(settings.brightness)

    var showIntro by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(900)
        showIntro = false
    }

    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    val navigate: (String) -> Unit = { route ->
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                if (current in Tabs.map { it.route }) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                        Tabs.forEach { tab ->
                            NavigationBarItem(
                                selected = current == tab.route,
                                onClick = { navigate(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label, maxLines = 1) }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = Routes.HOME,
                modifier = Modifier.padding(padding)
            ) {
                composable(Routes.HOME) {
                    HomeScreen(vm = vm, openClock = openClock, navigate = navigate, push = { nav.navigate(it) })
                }
                composable(Routes.TIMER) { TimerScreen(openClock = openClock) }
                composable(Routes.FOCUS) { FocusScreen(vm = vm, openClock = openClock) }
                composable(Routes.SCHEDULES) { SchedulesScreen(vm = vm, openSettings = { nav.navigate(Routes.SETTINGS) }) }
                composable(Routes.WORK) { WorkScreen(vm = vm, onFocusStarted = { navigate(Routes.FOCUS) }) }
                composable(Routes.STATS) { StatsScreen(vm = vm, onBack = { nav.popBackStack() }) }
                composable(Routes.SETTINGS) { SettingsScreen(vm = vm, onBack = { nav.popBackStack() }) }
            }
        }

        AnimatedVisibility(visible = showIntro, enter = fadeIn(), exit = fadeOut(tween(400))) {
            IntroSplash()
        }
    }
}

@Composable
private fun IntroSplash() {
    val anim = remember { Animatable(0.85f) }
    LaunchedEffect(Unit) { anim.animateTo(1f, tween(600)) }
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(
                Modifier
                    .size(96.dp)
                    .scale(anim.value)
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Timer,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(52.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "ScreenTime Pro",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.alpha(anim.value)
            )
            Text(
                "Smart Screen & Focus Timer",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 0.5.sp
            )
        }
    }
}
