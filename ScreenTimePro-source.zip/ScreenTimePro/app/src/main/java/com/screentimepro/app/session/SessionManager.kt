package com.screentimepro.app.session

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import com.screentimepro.app.ScreenTimeApp
import com.screentimepro.app.alarm.AlarmScheduler
import com.screentimepro.app.data.SessionRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

enum class SessionType(val title: String) { TIMER("Screen timer"), FOCUS("Focus session"), SCHEDULE("Scheduled session") }
enum class SessionStatus { IDLE, RUNNING, PAUSED }

data class SessionState(
    val status: SessionStatus = SessionStatus.IDLE,
    val type: SessionType = SessionType.TIMER,
    val label: String = "",
    val totalMs: Long = 0,
    /** Wall-clock end (survives reboot). */
    val endWall: Long = 0,
    /** elapsedRealtime end (immune to manual clock / time-zone changes while the phone stays on). */
    val endElapsed: Long = 0,
    val bootCount: Int = -1,
    val pausedRemainingMs: Long = 0,
    val startedWall: Long = 0,
    val taskId: Long = 0,
    val taskKind: String = "",
    val scheduleId: Long = 0
) {
    val isActive: Boolean get() = status != SessionStatus.IDLE
    val displayTitle: String get() = label.ifBlank { type.title }
}

/**
 * Single source of truth for the one active session. State is persisted on every change so the
 * correct remaining time is recovered after the app is closed, killed by the system, or the phone restarts.
 */
object SessionManager {
    private const val TAG = "SessionManager"
    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences

    private val _state = MutableStateFlow(SessionState())
    val state: StateFlow<SessionState> = _state.asStateFlow()

    fun init(context: Context) {
        app = context.applicationContext
        prefs = app.getSharedPreferences("active_session", Context.MODE_PRIVATE)
        _state.value = load()
        val s = _state.value
        if (s.status == SessionStatus.RUNNING) {
            if (remainingMs(s) <= 0) {
                complete()
            } else {
                reanchor()
                SessionService.start(app)
            }
        }
    }

    private fun bootCount(): Int = try {
        Settings.Global.getInt(app.contentResolver, Settings.Global.BOOT_COUNT)
    } catch (e: Exception) {
        -1
    }

    fun remainingMs(s: SessionState = _state.value): Long = when (s.status) {
        SessionStatus.RUNNING -> {
            val bc = bootCount()
            val r = if (bc != -1 && bc == s.bootCount) {
                s.endElapsed - SystemClock.elapsedRealtime()
            } else {
                s.endWall - System.currentTimeMillis()
            }
            r.coerceIn(0L, s.totalMs)
        }
        SessionStatus.PAUSED -> s.pausedRemainingMs
        SessionStatus.IDLE -> 0L
    }

    fun progress(s: SessionState = _state.value): Float =
        if (s.totalMs <= 0) 0f else (1f - remainingMs(s).toFloat() / s.totalMs).coerceIn(0f, 1f)

    @Synchronized
    fun start(
        type: SessionType,
        durationMs: Long,
        label: String = "",
        taskId: Long = 0,
        taskKind: String = "",
        scheduleId: Long = 0,
        wakeScreen: Boolean = false
    ) {
        if (durationMs < 1000) return
        if (_state.value.isActive) finish(completed = false)
        val now = System.currentTimeMillis()
        val s = SessionState(
            status = SessionStatus.RUNNING,
            type = type,
            label = label.trim(),
            totalMs = durationMs,
            endWall = now + durationMs,
            endElapsed = SystemClock.elapsedRealtime() + durationMs,
            bootCount = bootCount(),
            startedWall = now,
            taskId = taskId,
            taskKind = taskKind,
            scheduleId = scheduleId
        )
        set(s)
        AlarmScheduler.setSessionEndBackup(app, s.endWall)
        SessionService.start(app, wake = wakeScreen)
    }

    @Synchronized
    fun pause() {
        val s = _state.value
        if (s.status != SessionStatus.RUNNING) return
        set(s.copy(status = SessionStatus.PAUSED, pausedRemainingMs = remainingMs(s)))
        AlarmScheduler.cancelSessionEndBackup(app)
        SessionService.start(app)
    }

    @Synchronized
    fun resume() {
        val s = _state.value
        if (s.status != SessionStatus.PAUSED) return
        anchor(s.copy(status = SessionStatus.RUNNING), s.pausedRemainingMs)
        SessionService.start(app)
    }

    @Synchronized
    fun restart() {
        val s = _state.value
        if (!s.isActive) return
        anchor(s.copy(status = SessionStatus.RUNNING), s.totalMs)
        SessionService.start(app)
    }

    /** User stopped the session early. */
    fun stop() = finish(completed = false)

    /** Countdown reached zero. */
    fun complete() = finish(completed = true)

    /** Re-anchor both clocks after a reboot or manual time / time-zone change. */
    @Synchronized
    fun reanchor() {
        val s = _state.value
        if (s.status != SessionStatus.RUNNING) return
        val rem = remainingMs(s)
        if (rem <= 0) {
            complete()
            return
        }
        anchor(s, rem)
    }

    private fun anchor(s: SessionState, remaining: Long) {
        val now = System.currentTimeMillis()
        val n = s.copy(
            endWall = now + remaining,
            endElapsed = SystemClock.elapsedRealtime() + remaining,
            bootCount = bootCount(),
            pausedRemainingMs = 0
        )
        set(n)
        AlarmScheduler.setSessionEndBackup(app, n.endWall)
    }

    @Synchronized
    private fun finish(completed: Boolean) {
        val s = _state.value
        if (!s.isActive) return
        val remaining = if (completed) 0L else remainingMs(s)
        val actual = (s.totalMs - remaining).coerceAtLeast(0)
        val now = System.currentTimeMillis()
        set(SessionState())
        AlarmScheduler.cancelSessionEndBackup(app)

        val appInstance = app as ScreenTimeApp
        appInstance.appScope.launch(Dispatchers.IO) {
            try {
                val db = appInstance.database
                if (actual >= 1000) {
                    db.sessionDao().insert(
                        SessionRecord(
                            type = s.type.name,
                            label = s.displayTitle,
                            startedAt = s.startedWall,
                            endedAt = now,
                            plannedMs = s.totalMs,
                            actualMs = actual,
                            completed = completed,
                            taskId = s.taskId,
                            taskKind = s.taskKind
                        )
                    )
                    if (s.taskId > 0) {
                        when (s.taskKind) {
                            "fiverr" -> db.workTaskDao().addTime(s.taskId, actual)
                            "todo" -> db.todoDao().addFocus(s.taskId, actual)
                        }
                    }
                }
                val settings = appInstance.settings.flow.first()
                if (completed) {
                    Alerts.playCompletion(app, settings.sound, settings.vibration)
                }
                if (settings.notifications && (completed || s.type == SessionType.SCHEDULE)) {
                    Notifications.showSessionEnded(app, s.displayTitle, completed, actual)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to record session", e)
            }
        }
    }

    private fun set(s: SessionState) {
        _state.value = s
        prefs.edit()
            .putString("status", s.status.name)
            .putString("type", s.type.name)
            .putString("label", s.label)
            .putLong("totalMs", s.totalMs)
            .putLong("endWall", s.endWall)
            .putLong("endElapsed", s.endElapsed)
            .putInt("bootCount", s.bootCount)
            .putLong("pausedRemainingMs", s.pausedRemainingMs)
            .putLong("startedWall", s.startedWall)
            .putLong("taskId", s.taskId)
            .putString("taskKind", s.taskKind)
            .putLong("scheduleId", s.scheduleId)
            .commit()
    }

    private fun load(): SessionState = try {
        SessionState(
            status = SessionStatus.valueOf(prefs.getString("status", null) ?: SessionStatus.IDLE.name),
            type = SessionType.valueOf(prefs.getString("type", null) ?: SessionType.TIMER.name),
            label = prefs.getString("label", "") ?: "",
            totalMs = prefs.getLong("totalMs", 0),
            endWall = prefs.getLong("endWall", 0),
            endElapsed = prefs.getLong("endElapsed", 0),
            bootCount = prefs.getInt("bootCount", -1),
            pausedRemainingMs = prefs.getLong("pausedRemainingMs", 0),
            startedWall = prefs.getLong("startedWall", 0),
            taskId = prefs.getLong("taskId", 0),
            taskKind = prefs.getString("taskKind", "") ?: "",
            scheduleId = prefs.getLong("scheduleId", 0)
        )
    } catch (e: Exception) {
        SessionState()
    }
}
