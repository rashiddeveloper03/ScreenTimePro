package com.screentimepro.app.ui.components

import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Countdown text. Rounds up so the display reaches 00:00 exactly when the session ends. */
fun formatCountdown(ms: Long): String {
    val totalSec = ((ms.coerceAtLeast(0) + 999) / 1000)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}

/** Human duration like "2h 30m", "25m", "45s". */
fun formatDuration(ms: Long): String {
    val totalSec = ms.coerceAtLeast(0) / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    return when {
        h > 0 && m > 0 -> "${h}h ${m}m"
        h > 0 -> "${h}h"
        m > 0 -> "${m}m"
        else -> "${totalSec}s"
    }
}

fun formatMinutes(minutes: Int): String = formatDuration(minutes * 60_000L)

fun timeOfDay(hour: Int, minute: Int, use24h: Boolean): String {
    val t = LocalTime.of(hour.coerceIn(0, 23), minute.coerceIn(0, 59))
    return t.format(DateTimeFormatter.ofPattern(if (use24h) "HH:mm" else "h:mm a", Locale.US))
}

fun timeOfDay(epochMs: Long, use24h: Boolean): String {
    val t = Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault()).toLocalTime()
    return timeOfDay(t.hour, t.minute, use24h)
}

/** Main clock digits, without the AM/PM marker (shown separately). */
fun clockDigits(epochMs: Long, use24h: Boolean, seconds: Boolean): String {
    val pattern = when {
        use24h && seconds -> "HH:mm:ss"
        use24h -> "HH:mm"
        seconds -> "h:mm:ss"
        else -> "h:mm"
    }
    return Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern(pattern, Locale.US))
}

fun amPm(epochMs: Long): String =
    Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("a", Locale.US))

fun longDate(epochMs: Long): String =
    Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()))

fun shortDateTime(epochMs: Long, use24h: Boolean): String =
    Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern(if (use24h) "d MMM, HH:mm" else "d MMM, h:mm a", Locale.getDefault()))
