package com.screentimepro.app.session

import android.content.Context
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Completion sound / vibration, always gated by the user's in-app settings. */
object Alerts {

    fun playCompletion(ctx: Context, sound: Boolean, vibrate: Boolean) {
        if (sound) {
            runCatching {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                RingtoneManager.getRingtone(ctx, uri)?.play()
            }
        }
        if (vibrate) vibrate(ctx, longArrayOf(0, 350, 180, 350, 180, 500))
    }

    fun vibrate(ctx: Context, pattern: LongArray) {
        runCatching {
            val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (vibrator?.hasVibrator() == true) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            }
        }
    }
}
