@file:OptIn(ExperimentalMaterial3Api::class)

package com.screentimepro.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.screentimepro.app.data.SessionRecord
import com.screentimepro.app.session.SessionType
import com.screentimepro.app.ui.AppViewModel
import com.screentimepro.app.ui.components.EmptyState
import com.screentimepro.app.ui.components.SectionCard
import com.screentimepro.app.ui.components.StatTile
import com.screentimepro.app.ui.components.formatDuration
import com.screentimepro.app.ui.components.shortDateTime
import com.screentimepro.app.ui.theme.LocalAppSettings
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun StatsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val use24h = LocalAppSettings.current.use24h
    var confirmClear by remember { mutableStateOf(false) }
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now()

    fun dayOf(r: SessionRecord): LocalDate = Instant.ofEpochMilli(r.startedAt).atZone(zone).toLocalDate()

    val last7 = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val byDay = sessions.groupBy { dayOf(it) }
    val totals = last7.map { d -> byDay[d].orEmpty().sumOf { it.actualMs } }
    val focusTotals = last7.map { d -> byDay[d].orEmpty().filter { it.type == SessionType.FOCUS.name }.sumOf { it.actualMs } }
    val todayList = byDay[today].orEmpty()
    val weekMs = totals.sum()
    val streak = run {
        var n = 0
        var d = today
        while (byDay[d].orEmpty().any { it.type == SessionType.FOCUS.name && it.completed }) { n++; d = d.minusDays(1) }
        n
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("History & statistics") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") } },
                actions = { if (sessions.isNotEmpty()) TextButton(onClick = { confirmClear = true }) { Text("Clear") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile(formatDuration(todayList.sumOf { it.actualMs }), "Today", Modifier.weight(1f))
                    StatTile(formatDuration(weekMs), "Last 7 days", Modifier.weight(1f))
                    StatTile("$streak d", "Focus streak", Modifier.weight(1f), accent = MaterialTheme.colorScheme.tertiary)
                }
            }
            item {
                SectionCard(title = "Last 7 days") {
                    WeekChart(totals, focusTotals, last7.map { it.dayOfWeek.name.take(1) })
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LegendDot(MaterialTheme.colorScheme.primary); Text(" Focus   ", style = MaterialTheme.typography.labelMedium)
                        LegendDot(MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)); Text(" Other screen sessions", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            item {
                SectionCard(title = "Today") {
                    val focus = todayList.filter { it.type == SessionType.FOCUS.name }
                    Text("Focus: ${focus.count { it.completed }} completed · ${formatDuration(focus.sumOf { it.actualMs })}")
                    Text("Timers: ${todayList.count { it.type == SessionType.TIMER.name }} · Scheduled: ${todayList.count { it.type == SessionType.SCHEDULE.name }}")
                }
            }
            item { Text("Session history", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 4.dp)) }
            if (sessions.isEmpty()) {
                item { EmptyState(Icons.Rounded.BarChart, "No history yet", "Every timer, focus and scheduled session is logged here.") }
            }
            items(sessions.take(200), key = { it.id }) { r ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Icon(
                        when (r.type) {
                            SessionType.FOCUS.name -> Icons.Rounded.SelfImprovement
                            SessionType.SCHEDULE.name -> Icons.Rounded.Alarm
                            else -> Icons.Rounded.Timer
                        },
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${shortDateTime(r.startedAt, use24h)} · ${if (r.completed) "completed" else "stopped early"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        "${formatDuration(r.actualMs)}\n/ ${formatDuration(r.plannedMs)}",
                        style = MaterialTheme.typography.labelMedium,
                        textAlign = TextAlign.End
                    )
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all history?") },
            text = { Text("Session history and statistics are deleted. Tasks keep their tracked time.") },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun LegendDot(color: androidx.compose.ui.graphics.Color) {
    Canvas(Modifier.size(10.dp)) { drawCircle(color) }
}

@Composable
private fun WeekChart(totals: List<Long>, focus: List<Long>, labels: List<String>) {
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant
    val max = (totals.maxOrNull() ?: 0L).coerceAtLeast(60_000L)
    Column {
        Canvas(Modifier.fillMaxWidth().height(140.dp)) {
            val n = totals.size
            val slot = size.width / n
            val barW = slot * 0.5f
            totals.forEachIndexed { i, total ->
                val x = i * slot + (slot - barW) / 2f
                val r = CornerRadius(barW / 2f, barW / 2f)
                drawRoundRect(track, Offset(x, 0f), Size(barW, size.height), r)
                val h = size.height * (total.toFloat() / max)
                if (h > 0f) drawRoundRect(primary.copy(alpha = 0.35f), Offset(x, size.height - h), Size(barW, h), r)
                val fh = size.height * (focus[i].toFloat() / max)
                if (fh > 0f) drawRoundRect(primary, Offset(x, size.height - fh), Size(barW, fh), r)
            }
        }
        Row(Modifier.fillMaxWidth()) {
            labels.forEachIndexed { i, l ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(l, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        if (totals[i] > 0) formatDuration(totals[i]) else "–",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
