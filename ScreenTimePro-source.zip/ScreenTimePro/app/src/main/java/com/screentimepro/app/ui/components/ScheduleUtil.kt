package com.screentimepro.app.ui.components

import com.screentimepro.app.alarm.ScheduleCalc
import com.screentimepro.app.data.Schedule
import java.time.Duration
import java.time.LocalDate
import java.time.ZonedDateTime

data class UpcomingSession(val schedule: Schedule, val start: ZonedDateTime)

fun nextUpcoming(schedules: List<Schedule>, now: ZonedDateTime = ZonedDateTime.now()): UpcomingSession? =
    schedules.filter { it.enabled }
        .mapNotNull { s -> ScheduleCalc.nextStart(s, now)?.let { UpcomingSession(s, it) } }
        .minByOrNull { it.start.toInstant().toEpochMilli() }

fun relativeDay(start: ZonedDateTime): String {
    val today = LocalDate.now(start.zone)
    return when (start.toLocalDate()) {
        today -> "Today"
        today.plusDays(1) -> "Tomorrow"
        else -> start.dayOfWeek.name.take(3).lowercase().replaceFirstChar { it.uppercase() } +
            ", ${start.dayOfMonth} ${start.month.name.take(3).lowercase().replaceFirstChar { it.uppercase() }}"
    }
}

fun startsIn(start: ZonedDateTime, now: ZonedDateTime = ZonedDateTime.now()): String {
    val d = Duration.between(now, start)
    val mins = d.toMinutes()
    return when {
        mins < 1 -> "in under a minute"
        mins < 60 -> "in ${mins}m"
        mins < 24 * 60 -> "in ${mins / 60}h ${mins % 60}m"
        else -> "in ${mins / (24 * 60)}d ${(mins % (24 * 60)) / 60}h"
    }
}

fun scheduleEnd(s: Schedule): Pair<Int, Int> {
    val total = (s.startHour * 60 + s.startMinute + s.durationMinutes) % (24 * 60)
    return total / 60 to total % 60
}
