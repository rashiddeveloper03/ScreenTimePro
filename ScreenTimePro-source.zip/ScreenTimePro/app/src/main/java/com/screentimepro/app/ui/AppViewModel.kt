package com.screentimepro.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.screentimepro.app.ScreenTimeApp
import com.screentimepro.app.alarm.AlarmScheduler
import com.screentimepro.app.alarm.ScheduleCalc
import com.screentimepro.app.data.AppSettings
import com.screentimepro.app.data.Note
import com.screentimepro.app.data.Schedule
import com.screentimepro.app.data.SessionRecord
import com.screentimepro.app.data.TodoItem
import com.screentimepro.app.data.WorkTask
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.ZonedDateTime

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as ScreenTimeApp
    private val db = app.database

    /** null until DataStore has loaded (keeps the splash screen up, avoids a theme flash). */
    val settings: StateFlow<AppSettings?> = app.settings.flow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val schedules: StateFlow<List<Schedule>> = db.scheduleDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val sessions: StateFlow<List<SessionRecord>> = db.sessionDao()
        .observeSince(System.currentTimeMillis() - 60L * 24 * 3600 * 1000)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val workTasks: StateFlow<List<WorkTask>> = db.workTaskDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val todos: StateFlow<List<TodoItem>> = db.todoDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val notes: StateFlow<List<Note>> = db.noteDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { app.settings.update(transform) }
    }

    // ---- Schedules ----
    fun saveSchedule(s: Schedule) {
        viewModelScope.launch(Dispatchers.IO) {
            // If the new/edited window is already in progress, don't auto-start it on the next app
            // launch: the user can start a timer manually. It runs normally from the next occurrence.
            val window = ScheduleCalc.activeWindowStart(s, ZonedDateTime.now())
            val toSave = if (window != null) s.copy(lastTriggeredStart = window) else s
            val id = db.scheduleDao().save(toSave)
            val saved = if (toSave.id == 0L) toSave.copy(id = id) else toSave
            AlarmScheduler.scheduleOne(app, saved)
        }
    }

    fun setScheduleEnabled(s: Schedule, enabled: Boolean) = saveSchedule(s.copy(enabled = enabled))

    fun deleteSchedule(s: Schedule) {
        viewModelScope.launch(Dispatchers.IO) {
            AlarmScheduler.cancel(app, s.id)
            db.scheduleDao().delete(s)
        }
    }

    fun rescheduleAll() {
        viewModelScope.launch(Dispatchers.IO) { AlarmScheduler.rescheduleAll(app) }
    }

    // ---- Fiverr tasks ----
    fun saveWorkTask(t: WorkTask) {
        viewModelScope.launch(Dispatchers.IO) {
            val fixed = when {
                t.status == WorkTask.COMPLETED && t.completedAt == 0L -> t.copy(completedAt = System.currentTimeMillis())
                t.status != WorkTask.COMPLETED && t.completedAt != 0L -> t.copy(completedAt = 0)
                else -> t
            }
            db.workTaskDao().save(fixed)
        }
    }

    fun deleteWorkTask(t: WorkTask) {
        viewModelScope.launch(Dispatchers.IO) { db.workTaskDao().delete(t) }
    }

    // ---- To-dos ----
    fun saveTodo(t: TodoItem) {
        viewModelScope.launch(Dispatchers.IO) { db.todoDao().save(t) }
    }

    fun deleteTodo(t: TodoItem) {
        viewModelScope.launch(Dispatchers.IO) { db.todoDao().delete(t) }
    }

    // ---- Notes ----
    fun saveNote(n: Note) {
        viewModelScope.launch(Dispatchers.IO) { db.noteDao().save(n.copy(updatedAt = System.currentTimeMillis())) }
    }

    fun deleteNote(n: Note) {
        viewModelScope.launch(Dispatchers.IO) { db.noteDao().delete(n) }
    }

    // ---- History ----
    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) { db.sessionDao().clearAll() }
    }
}
