package com.screentimepro.app.ui.clock

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.screentimepro.app.session.SessionManager
import com.screentimepro.app.session.SessionStatus
import com.screentimepro.app.ui.components.KeepScreenOnEffect
import com.screentimepro.app.ui.components.WindowBrightnessEffect
import com.screentimepro.app.ui.components.amPm
import com.screentimepro.app.ui.components.clockDigits
import com.screentimepro.app.ui.components.formatCountdown
import com.screentimepro.app.ui.components.longDate
import com.screentimepro.app.ui.components.rememberHaptic
import com.screentimepro.app.ui.components.rememberNow
import com.screentimepro.app.ui.theme.LocalAppSettings
import com.screentimepro.app.ui.theme.clockStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun FullScreenClock(onExit: () -> Unit) {
    val settings = LocalAppSettings.current
    val session by SessionManager.state.collectAsStateWithLifecycle()
    val now = rememberNow()
    val running = session.status == SessionStatus.RUNNING

    KeepScreenOnEffect(running)
    WindowBrightnessEffect(if (settings.dimClock) 0.06f else settings.brightness)

    // Taps only reveal controls; they never stop the session.
    var controlsVisible by remember { mutableStateOf(false) }
    var interaction by remember { mutableIntStateOf(0) }
    LaunchedEffect(controlsVisible, interaction) {
        if (controlsVisible) {
            delay(5_000)
            controlsVisible = false
        }
    }

    var sawSession by remember { mutableStateOf(session.isActive) }
    LaunchedEffect(session.isActive) { if (session.isActive) sawSession = true }
    val finished = sawSession && !session.isActive

    val style = clockStyle(settings.clockFont)
    val contentAlpha = if (settings.dimClock) 0.55f else 1f
    val minuteIndex = (now / 60_000L).toInt()
    val shiftX = if (settings.burnInShift) ((minuteIndex % 5) - 2) * 6 else 0
    val shiftY = if (settings.burnInShift) (((minuteIndex / 5) % 5) - 2) * 6 else 0
    val accent = MaterialTheme.colorScheme.primary

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    controlsVisible = !controlsVisible
                    interaction++
                })
            }
    ) {
        val density = LocalDensity.current
        val digits = clockDigits(now, settings.use24h, settings.showSeconds)
        val widthPx = with(density) { maxWidth.toPx() } * 0.9f
        val autoSize = with(density) { (widthPx / (digits.length * 0.62f)).toSp() }
        val clockSize = (autoSize.value * settings.clockScale).coerceIn(36f, 160f).sp

        Column(
            Modifier
                .fillMaxWidth()
                .align(Alignment.Center)
                .offset(x = shiftX.dp, y = shiftY.dp)
                .alpha(contentAlpha),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    digits,
                    fontFamily = style.family,
                    fontWeight = style.weight,
                    fontSize = clockSize,
                    color = Color.White,
                    maxLines = 1
                )
                if (!settings.use24h) {
                    Text(
                        amPm(now),
                        fontSize = (clockSize.value * 0.22f).sp,
                        color = accent,
                        modifier = Modifier.padding(start = 4.dp, bottom = (clockSize.value * 0.18f).dp)
                    )
                }
            }
            Text(
                longDate(now),
                fontSize = (16 * settings.clockScale).coerceIn(13f, 22f).sp,
                color = Color(0xFFB8B8C8)
            )

            Spacer(Modifier.height(36.dp))
            if (session.isActive) {
                val remaining = SessionManager.remainingMs(session)
                Text(
                    session.displayTitle.uppercase(),
                    fontSize = 13.sp,
                    letterSpacing = 2.sp,
                    color = accent
                )
                Text(
                    formatCountdown(remaining),
                    fontFamily = style.family,
                    fontWeight = style.weight,
                    fontSize = (clockSize.value * 0.55f).sp,
                    color = if (running) Color.White else Color(0xFF8A8A9A)
                )
                if (!running) Text("Paused", color = Color(0xFF8A8A9A), fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { SessionManager.progress(session) },
                    modifier = Modifier.width(220.dp).height(4.dp).clip(CircleShape),
                    color = accent,
                    trackColor = Color(0xFF26262E)
                )
            } else if (finished) {
                Text("Session complete", fontSize = 22.sp, color = accent)
                Text(
                    "The screen can now turn off normally.",
                    fontSize = 14.sp,
                    color = Color(0xFF8A8A9A),
                    textAlign = TextAlign.Center
                )
            }
        }

        if (!controlsVisible) {
            Text(
                "Tap to show controls",
                fontSize = 11.sp,
                color = Color(0xFF44444F),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp)
            )
        }

        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Column(
                Modifier.fillMaxWidth().padding(bottom = 36.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (session.isActive) {
                        FilledTonalButton(onClick = {
                            interaction++
                            if (running) SessionManager.pause() else SessionManager.resume()
                        }) {
                            Icon(if (running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (running) "Pause" else "Resume")
                        }
                        HoldToStopButton(onConfirmed = { SessionManager.stop() }, onPress = { interaction++ })
                    }
                    FilledTonalButton(onClick = onExit) {
                        Icon(Icons.Rounded.Close, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Exit")
                    }
                }
                if (session.isActive) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Hold the stop button to end the session. Exit keeps it running.",
                        fontSize = 12.sp,
                        color = Color(0xFF8A8A9A)
                    )
                }
            }
        }
    }
}

@Composable
private fun HoldToStopButton(onConfirmed: () -> Unit, onPress: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val confirmed by rememberUpdatedState(onConfirmed)
    val pressed by rememberUpdatedState(onPress)
    val haptic = rememberHaptic(strong = true)
    val accent = MaterialTheme.colorScheme.error

    Box(
        Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(Color(0xFF1E1E26))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    pressed()
                    val job = scope.launch {
                        progress.animateTo(1f, tween(1_500, easing = LinearEasing))
                        haptic()
                        confirmed()
                        progress.snapTo(0f)
                    }
                    tryAwaitRelease()
                    if (progress.value < 1f) {
                        job.cancel()
                        scope.launch { progress.animateTo(0f, tween(200)) }
                    }
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 4.dp.toPx()
            val d = size.minDimension - w
            drawArc(
                accent, -90f, 360f * progress.value, false,
                Offset(w / 2, w / 2), Size(d, d),
                style = Stroke(w, cap = StrokeCap.Round)
            )
        }
        Icon(Icons.Rounded.Stop, contentDescription = "Hold to stop session", tint = accent)
    }
}
