package com.screentimepro.app.ui.clock

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.screentimepro.app.ScreenTimeApp
import com.screentimepro.app.data.AppSettings
import com.screentimepro.app.data.ThemeMode
import com.screentimepro.app.session.Notifications
import com.screentimepro.app.ui.theme.ScreenTimeTheme

/**
 * Full-screen clock. Can appear over the lock screen and turn the display on (used by scheduled
 * sessions through a full-screen notification). It never dismisses or bypasses a secure keyguard.
 */
class ClockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        enableEdgeToEdge()
        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        // The schedule alert has done its job once the clock is visible.
        Notifications.cancel(this, Notifications.ID_ALERT)

        val repo = (application as ScreenTimeApp).settings
        setContent {
            val settings = repo.flow.collectAsStateWithLifecycle(initialValue = null).value ?: AppSettings()
            // The clock is always dark; AMOLED black when the user picked it.
            val clockTheme = settings.copy(
                themeMode = if (settings.themeMode == ThemeMode.AMOLED) ThemeMode.AMOLED else ThemeMode.DARK
            )
            ScreenTimeTheme(clockTheme) {
                FullScreenClock(onExit = { finish() })
            }
        }
    }
}
