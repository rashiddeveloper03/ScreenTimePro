package com.screentimepro.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.screentimepro.app.session.SessionManager
import com.screentimepro.app.session.SessionType
import com.screentimepro.app.ui.components.ActiveSessionPanel
import com.screentimepro.app.ui.components.DurationChips
import com.screentimepro.app.ui.components.DurationPickerDialog
import com.screentimepro.app.ui.components.QUICK_DURATIONS_MIN
import com.screentimepro.app.ui.components.SectionCard
import com.screentimepro.app.ui.components.formatCountdown
import com.screentimepro.app.ui.components.formatMinutes
import com.screentimepro.app.ui.components.rememberHaptic
import com.screentimepro.app.ui.components.rememberNow
import com.screentimepro.app.ui.components.timeOfDay
import com.screentimepro.app.ui.theme.LocalAppSettings
import com.screentimepro.app.ui.theme.TimerDigits

@Composable
fun TimerScreen(openClock: () -> Unit) {
    val session by SessionManager.state.collectAsStateWithLifecycle()
    var minutes by rememberSaveable { mutableIntStateOf(30) }
    var label by rememberSaveable { mutableStateOf("") }
    var showCustom by rememberSaveable { mutableStateOf(false) }
    val haptic = rememberHaptic(strong = true)
    val now = rememberNow()
    val use24h = LocalAppSettings.current.use24h

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Smart Screen Timer", style = MaterialTheme.typography.headlineSmall)
        Text(
            "The display stays on for the time you choose, then the session ends on its own.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (session.isActive) {
            SectionCard {
                ActiveSessionPanel(state = session, onFullscreen = openClock)
            }
        } else {
            SectionCard {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        formatCountdown(minutes * 60_000L),
                        style = TimerDigits.copy(fontSize = 64.sp),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        "Screen off at ${timeOfDay(now + minutes * 60_000L, use24h)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(16.dp))
                DurationChips(
                    selectedMinutes = if (minutes in QUICK_DURATIONS_MIN) minutes else null,
                    onSelect = { minutes = it }
                )
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = { showCustom = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Edit, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (minutes in QUICK_DURATIONS_MIN) "Custom duration" else "Custom: ${formatMinutes(minutes)}")
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it.take(40) },
                    label = { Text("Label (optional)") },
                    placeholder = { Text("e.g. Reading, Cooking, Presentation") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                Row {
                    Button(
                        onClick = {
                            haptic()
                            SessionManager.start(SessionType.TIMER, minutes * 60_000L, label)
                        },
                        modifier = Modifier.weight(1f).height(56.dp)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Start ${formatMinutes(minutes)}")
                    }
                }
            }
        }

        SectionCard(title = "How it works") {
            Text(
                "• While the app is open the screen is kept on with the standard Android flag.\n" +
                    "• If you switch apps, a notification with a live countdown keeps the display awake (turn off in Settings).\n" +
                    "• Pressing the power button still turns the screen off — Android doesn't let apps block that.\n" +
                    "• If the app is closed or the phone restarts, the remaining time is restored automatically.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    if (showCustom) {
        DurationPickerDialog(
            initialMinutes = minutes,
            onDismiss = { showCustom = false },
            onConfirm = { minutes = it; showCustom = false }
        )
    }
}
