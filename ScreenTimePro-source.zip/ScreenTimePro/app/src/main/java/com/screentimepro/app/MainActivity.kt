package com.screentimepro.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.screentimepro.app.data.AppSettings
import com.screentimepro.app.ui.AppRoot
import com.screentimepro.app.ui.AppViewModel
import com.screentimepro.app.ui.clock.ClockActivity
import com.screentimepro.app.ui.theme.ScreenTimeTheme

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { vm.settings.value == null }
        enableEdgeToEdge()
        setContent {
            val settings = vm.settings.collectAsStateWithLifecycle().value ?: AppSettings()
            ScreenTimeTheme(settings) {
                AppRoot(
                    vm = vm,
                    openClock = { startActivity(Intent(this, ClockActivity::class.java)) }
                )
            }
        }
    }
}
