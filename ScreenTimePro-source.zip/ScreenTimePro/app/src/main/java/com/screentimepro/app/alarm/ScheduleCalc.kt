package com.screentimepro.app.alarm

import com.screentimepro.app.data.Schedule
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime

/** Pure schedule math (no Android dependencies) so it can be unit-tested on the JVM. */
object ScheduleCalc {

    const val MAX_DURATION_MINUTES = 24 * 60

    fun dayBit(day: DayOfWeek): Int = 1 shl (day.value - 1)

    fun isDayEnabled(mask: Int, day: DayOfWeek): Boolean = (mask and dayBit(day)) != 0

    private fun startTime(s: Schedule): LocalTime =
        LocalTime.of(s.startHour.coerceIn(0, 23), s.startMinute.coerceIn(0, 59))

    /** Next start strictly after [now], or null if a one-time schedule is in the past / no days chosen. */
    fun nextStart(s: Schedule, now: ZonedDateTime): ZonedDateTime? {
        val time = startTime(s)
        if (s.repeatDays == 0) {
            if (s.oneTimeEpochDay <= 0) return null
            val dt = LocalDate.ofEpochDay(s.oneTimeEpochDay).atTime(time).atZone(now.zone)
            return if (dt.isAfter(now)) dt else null
        }
        for (d in 0..7) {
            val date = now.toLocalDate().plusDays(d.toLong())
            if (!isDayEnabled(s.repeatDays, date.dayOfWeek)) continue
            val dt = date.atTime(time).atZone(now.zone)
            if (dt.isAfter(now)) return dt
        }
        return null
    }

    /** Epoch millis of the occurrence whose window [start, start+duration) contains [now], or null. */
    fun activeWindowStart(s: Schedule, now: ZonedDateTime): Long? {
        val time = startTime(s)
        val durMs = s.durationMinutes.coerceIn(1, MAX_DURATION_MINUTES) * 60_000L
        val nowMs = now.toInstant().toEpochMilli()
        val dates: List<LocalDate> = if (s.repeatDays == 0) {
            if (s.oneTimeEpochDay <= 0) emptyList() else listOf(LocalDate.ofEpochDay(s.oneTimeEpochDay))
        } else {
            listOf(now.toLocalDate().minusDays(1), now.toLocalDate())
                .filter { isDayEnabled(s.repeatDays, it.dayOfWeek) }
        }
        for (date in dates) {
            val start = date.atTime(time).atZone(now.zone).toInstant().toEpochMilli()
            if (nowMs >= start && nowMs < start + durMs) return start
        }
        return null
    }

    /** Minutes between a start and an end time of day; wraps past midnight. */
    fun minutesBetween(startH: Int, startM: Int, endH: Int, endM: Int): Int {
        val start = startH * 60 + startM
        val end = endH * 60 + endM
        val diff = end - start
        return if (diff <= 0) diff + 24 * 60 else diff
    }

    fun repeatLabel(s: Schedule): String = when (s.repeatDays) {
        0 -> if (s.oneTimeEpochDay > 0) "Once · " + LocalDate.ofEpochDay(s.oneTimeEpochDay).let {
            "${it.dayOfWeek.name.take(3).lowercase().replaceFirstChar { c -> c.uppercase() }}, ${it.dayOfMonth} ${it.month.name.take(3).lowercase().replaceFirstChar { c -> c.uppercase() }}"
        } else "Once"
        Schedule.EVERY_DAY -> "Every day"
        Schedule.WEEKDAYS -> "Weekdays"
        Schedule.WEEKEND -> "Weekends"
        else -> DayOfWeek.values().filter { isDayEnabled(s.repeatDays, it) }
            .joinToString(" ") { it.name.take(2).lowercase().replaceFirstChar { c -> c.uppercase() } }
    }
}
