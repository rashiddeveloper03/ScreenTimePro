@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.screentimepro.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.screentimepro.app.alarm.AlarmScheduler
import com.screentimepro.app.alarm.ScheduleCalc
import com.screentimepro.app.data.Schedule
import com.screentimepro.app.ui.AppViewModel
import com.screentimepro.app.ui.components.DatePickerDialogBox
import com.screentimepro.app.ui.components.DurationChips
import com.screentimepro.app.ui.components.DurationPickerDialog
import com.screentimepro.app.ui.components.EmptyState
import com.screentimepro.app.ui.components.SectionCard
import com.screentimepro.app.ui.components.TimePickerDialog
import com.screentimepro.app.ui.components.epochDayToLabel
import com.screentimepro.app.ui.components.formatMinutes
import com.screentimepro.app.ui.components.nextUpcoming
import com.screentimepro.app.ui.components.rememberNow
import com.screentimepro.app.ui.components.relativeDay
import com.screentimepro.app.ui.components.scheduleEnd
import com.screentimepro.app.ui.components.startsIn
import com.screentimepro.app.ui.components.timeOfDay
import com.screentimepro.app.ui.theme.LocalAppSettings
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime

@Composable
fun SchedulesScreen(vm: AppViewModel, openSettings: () -> Unit) {
    val schedules by vm.schedules.collectAsStateWithLifecycle()
    val use24h = LocalAppSettings.current.use24h
    val ctx = LocalContext.current
    var editing by remember { mutableStateOf<Schedule?>(null) }
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Schedule?>(null) }
    var exactOk by remember { mutableStateOf(AlarmScheduler.canScheduleExact(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { exactOk = AlarmScheduler.canScheduleExact(ctx) }
    val now = rememberNow(30_000)
    val upcoming = remember(schedules, now) { nextUpcoming(schedules) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Schedules", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Turn the screen on automatically at a set time and keep it on for as long as you choose.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!exactOk) {
                item {
                    SectionCard(container = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "Exact alarms are off, so schedules may start several minutes late.",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = openSettings) { Text("Fix") }
                        }
                    }
                }
            }
            item {
                SectionCard(title = "Next up") {
                    if (upcoming == null) {
                        Text("Nothing scheduled", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text(upcoming.schedule.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${relativeDay(upcoming.start)} at ${timeOfDay(upcoming.start.hour, upcoming.start.minute, use24h)} · ${startsIn(upcoming.start)}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (schedules.isEmpty()) {
                item {
                    EmptyState(
                        Icons.Rounded.Alarm,
                        "No schedules yet",
                        "Example: start 9:00 AM, keep the screen on for 2 hours, repeat on weekdays."
                    )
                }
            }
            items(schedules, key = { it.id }) { s ->
                ScheduleCard(
                    s = s,
                    use24h = use24h,
                    onToggle = { vm.setScheduleEnabled(s, it) },
                    onEdit = { editing = s },
                    onDelete = { deleting = s }
                )
            }
        }
        ExtendedFloatingActionButton(
            onClick = { creating = true },
            icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
            text = { Text("New schedule") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        )
    }

    if (creating || editing != null) {
        ScheduleEditor(
            initial = editing,
            use24h = use24h,
            onDismiss = { creating = false; editing = null },
            onSave = { vm.saveSchedule(it); creating = false; editing = null }
        )
    }
    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete \"${s.name}\"?") },
            text = { Text("Its alarm is cancelled immediately.") },
            confirmButton = { TextButton(onClick = { vm.deleteSchedule(s); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ScheduleCard(
    s: Schedule,
    use24h: Boolean,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val (eh, em) = scheduleEnd(s)
    Card(
        onClick = onEdit,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        Row(Modifier.padding(start = 18.dp, top = 14.dp, bottom = 14.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "${timeOfDay(s.startHour, s.startMinute, use24h)} – ${timeOfDay(eh, em, use24h)}",
                    style = MaterialTheme.typography.titleLarge,
                    color = if (s.enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(s.name, style = MaterialTheme.typography.bodyLarge)
                Text(
                    "${ScheduleCalc.repeatLabel(s)} · ${formatMinutes(s.durationMinutes)}${if (s.wakeScreen) " · wakes screen" else ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = s.enabled, onCheckedChange = onToggle)
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Delete schedule") }
        }
    }
}

private val DayLetters = listOf("M", "T", "W", "T", "F", "S", "S")

@Composable
private fun ScheduleEditor(
    initial: Schedule?,
    use24h: Boolean,
    onDismiss: () -> Unit,
    onSave: (Schedule) -> Unit
) {
    val nowTime = LocalTime.now().plusMinutes(5)
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var hour by remember { mutableIntStateOf(initial?.startHour ?: nowTime.hour) }
    var minute by remember { mutableIntStateOf(initial?.startMinute ?: nowTime.minute) }
    var duration by remember { mutableIntStateOf(initial?.durationMinutes ?: 60) }
    var useEndTime by remember { mutableStateOf(false) }
    // 0 = one time, 1 = daily, 2 = custom days
    var repeatMode by remember {
        mutableIntStateOf(
            when (initial?.repeatDays) {
                null, 0 -> 0
                Schedule.EVERY_DAY -> 1
                else -> 2
            }
        )
    }
    var days by remember { mutableIntStateOf(initial?.repeatDays?.takeIf { it != 0 } ?: Schedule.WEEKDAYS) }
    var date by remember {
        mutableLongStateOf(
            initial?.oneTimeEpochDay?.takeIf { it > 0 } ?: run {
                val t = LocalTime.now()
                if (LocalTime.of(hour, minute).isAfter(t)) LocalDate.now().toEpochDay() else LocalDate.now().plusDays(1).toEpochDay()
            }
        )
    }
    var wake by remember { mutableStateOf(initial?.wakeScreen ?: true) }
    var pickStart by remember { mutableStateOf(false) }
    var pickEnd by remember { mutableStateOf(false) }
    var pickDate by remember { mutableStateOf(false) }
    var pickDuration by remember { mutableStateOf(false) }

    val (eh, em) = run {
        val total = (hour * 60 + minute + duration) % (24 * 60)
        total / 60 to total % 60
    }
    val repeatDays = when (repeatMode) { 0 -> 0; 1 -> Schedule.EVERY_DAY; else -> days }
    val draft = Schedule(
        id = initial?.id ?: 0,
        name = name.trim().ifBlank { "Screen on" },
        startHour = hour,
        startMinute = minute,
        durationMinutes = duration,
        repeatDays = repeatDays,
        oneTimeEpochDay = if (repeatMode == 0) date else 0,
        enabled = true,
        wakeScreen = wake,
        lastTriggeredStart = initial?.lastTriggeredStart ?: 0,
        createdAt = initial?.createdAt ?: System.currentTimeMillis()
    )
    val error = when {
        repeatMode == 2 && days == 0 -> "Pick at least one day"
        duration !in 1..ScheduleCalc.MAX_DURATION_MINUTES -> "Duration must be between 1 minute and 24 hours"
        repeatMode == 0 && ScheduleCalc.nextStart(draft, ZonedDateTime.now()) == null -> "That date and time has already passed"
        else -> null
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.fillMaxWidth(0.94f).imePadding()
        ) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(if (initial == null) "New schedule" else "Edit schedule", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    label = { Text("Name") },
                    placeholder = { Text("e.g. Morning dashboard") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Start time", style = MaterialTheme.typography.labelLarge)
                OutlinedButton(onClick = { pickStart = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(timeOfDay(hour, minute, use24h), style = MaterialTheme.typography.headlineSmall)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !useEndTime, onClick = { useEndTime = false }, label = { Text("Set duration") })
                    FilterChip(selected = useEndTime, onClick = { useEndTime = true }, label = { Text("Set end time") })
                }
                if (useEndTime) {
                    OutlinedButton(onClick = { pickEnd = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Ends ${timeOfDay(eh, em, use24h)} · ${formatMinutes(duration)}")
                    }
                } else {
                    DurationChips(selectedMinutes = duration, onSelect = { duration = it })
                    TextButton(onClick = { pickDuration = true }) {
                        Text("Custom duration (${formatMinutes(duration)}) · ends ${timeOfDay(eh, em, use24h)}")
                    }
                }

                Text("Repeat", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = repeatMode == 0, onClick = { repeatMode = 0 }, label = { Text("Once") })
                    FilterChip(selected = repeatMode == 1, onClick = { repeatMode = 1 }, label = { Text("Daily") })
                    FilterChip(selected = repeatMode == 2, onClick = { repeatMode = 2 }, label = { Text("Days") })
                }
                when (repeatMode) {
                    0 -> OutlinedButton(onClick = { pickDate = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Date: ${epochDayToLabel(date)} (${LocalDate.ofEpochDay(date)})")
                    }
                    2 -> FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DayOfWeek.values().forEachIndexed { i, d ->
                            val bit = ScheduleCalc.dayBit(d)
                            FilterChip(
                                selected = days and bit != 0,
                                onClick = { days = days xor bit },
                                label = { Text(DayLetters[i]) }
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Wake the screen", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Turns the display on and shows the clock over the lock screen. Your PIN is still required to use other apps.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = wake, onCheckedChange = { wake = it })
                }

                if (error != null) {
                    Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(Modifier.width(8.dp))
                    androidx.compose.material3.Button(enabled = error == null, onClick = { onSave(draft) }) { Text("Save") }
                }
            }
        }
    }

    if (pickStart) {
        TimePickerDialog(hour, minute, use24h, "Start time", onDismiss = { pickStart = false }) { h, m ->
            hour = h; minute = m; pickStart = false
        }
    }
    if (pickEnd) {
        TimePickerDialog(eh, em, use24h, "End time", onDismiss = { pickEnd = false }) { h, m ->
            duration = ScheduleCalc.minutesBetween(hour, minute, h, m); pickEnd = false
        }
    }
    if (pickDuration) {
        DurationPickerDialog(
            initialMinutes = duration,
            maxHours = 23,
            onDismiss = { pickDuration = false },
            onConfirm = { duration = it; pickDuration = false }
        )
    }
    if (pickDate) {
        DatePickerDialogBox(date, onDismiss = { pickDate = false }) { d -> date = d; pickDate = false }
    }
}
