package com.screentimepro.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.screentimepro.app.session.SessionManager
import com.screentimepro.app.session.SessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Reboot, app update, manual time change, time-zone change, exact-alarm permission change. */
class SystemEventReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val ctx = context.applicationContext
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                SessionManager.reanchor()
                if (SessionManager.state.value.isActive) SessionService.start(ctx)
                AlarmScheduler.rescheduleAll(ctx)
            } catch (e: Exception) {
                Log.e("SystemEventReceiver", "Failed handling ${intent.action}", e)
            } finally {
                pending.finish()
            }
        }
    }
}
