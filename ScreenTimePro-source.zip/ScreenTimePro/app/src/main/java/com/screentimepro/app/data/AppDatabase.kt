package com.screentimepro.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM schedules ORDER BY startHour, startMinute, id")
    fun observeAll(): Flow<List<Schedule>>

    @Query("SELECT * FROM schedules")
    suspend fun getAll(): List<Schedule>

    @Query("SELECT * FROM schedules WHERE id = :id")
    suspend fun getById(id: Long): Schedule?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(schedule: Schedule): Long

    @Delete
    suspend fun delete(schedule: Schedule)
}

@Dao
interface SessionDao {
    @Insert
    suspend fun insert(record: SessionRecord): Long

    @Query("SELECT * FROM session_records WHERE startedAt >= :from ORDER BY startedAt DESC")
    fun observeSince(from: Long): Flow<List<SessionRecord>>

    @Query("DELETE FROM session_records")
    suspend fun clearAll()
}

@Dao
interface WorkTaskDao {
    @Query("SELECT * FROM work_tasks ORDER BY status, CASE WHEN deadline = 0 THEN 1 ELSE 0 END, deadline, priority DESC")
    fun observeAll(): Flow<List<WorkTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(task: WorkTask): Long

    @Delete
    suspend fun delete(task: WorkTask)

    @Query("UPDATE work_tasks SET timeSpentMs = timeSpentMs + :ms WHERE id = :id")
    suspend fun addTime(id: Long, ms: Long)
}

@Dao
interface TodoDao {
    @Query("SELECT * FROM todos ORDER BY done, CASE WHEN dueEpochDay = 0 THEN 1 ELSE 0 END, dueEpochDay, priority DESC, createdAt DESC")
    fun observeAll(): Flow<List<TodoItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(item: TodoItem): Long

    @Delete
    suspend fun delete(item: TodoItem)

    @Query("UPDATE todos SET focusMs = focusMs + :ms WHERE id = :id")
    suspend fun addFocus(id: Long, ms: Long)
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY pinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<Note>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(note: Note): Long

    @Delete
    suspend fun delete(note: Note)
}

@Database(
    entities = [Schedule::class, SessionRecord::class, WorkTask::class, TodoItem::class, Note::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scheduleDao(): ScheduleDao
    abstract fun sessionDao(): SessionDao
    abstract fun workTaskDao(): WorkTaskDao
    abstract fun todoDao(): TodoDao
    abstract fun noteDao(): NoteDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "screentime.db").build()
    }
}
