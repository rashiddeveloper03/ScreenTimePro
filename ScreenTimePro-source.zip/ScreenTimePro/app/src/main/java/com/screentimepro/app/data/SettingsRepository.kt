package com.screentimepro.app.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode { SYSTEM, LIGHT, DARK, AMOLED }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: Int = 0,
    val use24h: Boolean = false,
    val showSeconds: Boolean = true,
    /** 0 classic, 1 mono, 2 serif, 3 thin */
    val clockFont: Int = 0,
    val clockScale: Float = 1f,
    val dimClock: Boolean = false,
    /** In-app window brightness 0.02..1, or -1 to follow the system. Never changes system settings. */
    val brightness: Float = -1f,
    val sound: Boolean = true,
    val vibration: Boolean = true,
    val haptics: Boolean = true,
    val notifications: Boolean = true,
    val keepScreenOnOutsideApp: Boolean = true,
    val focusGoal: Int = 4,
    val burnInShift: Boolean = true
)

private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {

    private object K {
        val theme = stringPreferencesKey("theme")
        val accent = intPreferencesKey("accent")
        val use24h = booleanPreferencesKey("use24h")
        val showSeconds = booleanPreferencesKey("showSeconds")
        val clockFont = intPreferencesKey("clockFont")
        val clockScale = floatPreferencesKey("clockScale")
        val dimClock = booleanPreferencesKey("dimClock")
        val brightness = floatPreferencesKey("brightness")
        val sound = booleanPreferencesKey("sound")
        val vibration = booleanPreferencesKey("vibration")
        val haptics = booleanPreferencesKey("haptics")
        val notifications = booleanPreferencesKey("notifications")
        val keepOn = booleanPreferencesKey("keepScreenOnOutsideApp")
        val focusGoal = intPreferencesKey("focusGoal")
        val burnIn = booleanPreferencesKey("burnInShift")
    }

    val flow: Flow<AppSettings> = context.dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { read(it) }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { prefs -> write(prefs, transform(read(prefs))) }
    }

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            themeMode = p[K.theme]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: d.themeMode,
            accent = p[K.accent] ?: d.accent,
            use24h = p[K.use24h] ?: d.use24h,
            showSeconds = p[K.showSeconds] ?: d.showSeconds,
            clockFont = p[K.clockFont] ?: d.clockFont,
            clockScale = p[K.clockScale] ?: d.clockScale,
            dimClock = p[K.dimClock] ?: d.dimClock,
            brightness = p[K.brightness] ?: d.brightness,
            sound = p[K.sound] ?: d.sound,
            vibration = p[K.vibration] ?: d.vibration,
            haptics = p[K.haptics] ?: d.haptics,
            notifications = p[K.notifications] ?: d.notifications,
            keepScreenOnOutsideApp = p[K.keepOn] ?: d.keepScreenOnOutsideApp,
            focusGoal = p[K.focusGoal] ?: d.focusGoal,
            burnInShift = p[K.burnIn] ?: d.burnInShift
        )
    }

    private fun write(p: MutablePreferences, s: AppSettings) {
        p[K.theme] = s.themeMode.name
        p[K.accent] = s.accent
        p[K.use24h] = s.use24h
        p[K.showSeconds] = s.showSeconds
        p[K.clockFont] = s.clockFont
        p[K.clockScale] = s.clockScale
        p[K.dimClock] = s.dimClock
        p[K.brightness] = s.brightness
        p[K.sound] = s.sound
        p[K.vibration] = s.vibration
        p[K.haptics] = s.haptics
        p[K.notifications] = s.notifications
        p[K.keepOn] = s.keepScreenOnOutsideApp
        p[K.focusGoal] = s.focusGoal
        p[K.burnIn] = s.burnInShift
    }
}
