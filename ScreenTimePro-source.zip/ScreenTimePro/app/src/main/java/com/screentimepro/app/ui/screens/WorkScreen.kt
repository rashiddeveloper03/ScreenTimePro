@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package com.screentimepro.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.screentimepro.app.data.Note
import com.screentimepro.app.data.SessionRecord
import com.screentimepro.app.data.TodoItem
import com.screentimepro.app.data.WorkTask
import com.screentimepro.app.ui.AppViewModel
import com.screentimepro.app.ui.components.DatePickerDialogBox
import com.screentimepro.app.ui.components.EmptyState
import com.screentimepro.app.ui.components.Pill
import com.screentimepro.app.ui.components.PriorityBadge
import com.screentimepro.app.ui.components.PriorityNames
import com.screentimepro.app.ui.components.SectionCard
import com.screentimepro.app.ui.components.StatTile
import com.screentimepro.app.ui.components.TimePickerDialog
import com.screentimepro.app.ui.components.epochDayToLabel
import com.screentimepro.app.ui.components.formatDuration
import com.screentimepro.app.ui.components.rememberHaptic
import com.screentimepro.app.ui.components.shortDateTime
import com.screentimepro.app.ui.components.startOfToday
import com.screentimepro.app.ui.theme.LocalAppSettings
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

private val StatusNames = listOf("Pending", "In progress", "Completed")

@Composable
fun WorkScreen(vm: AppViewModel, onFocusStarted: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var subTab by rememberSaveable { mutableIntStateOf(0) }
    var editingTask by remember { mutableStateOf<WorkTask?>(null) }
    var editingTodo by remember { mutableStateOf<TodoItem?>(null) }
    var editingNote by remember { mutableStateOf<Note?>(null) }
    var focusFor by remember { mutableStateOf<TaskLink?>(null) }

    Column(Modifier.fillMaxSize()) {
        Text(
            "Work",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
        )
        PrimaryTabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Fiverr orders") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Workspace") })
        }
        Box(Modifier.weight(1f)) {
            if (tab == 0) {
                FiverrTab(
                    vm = vm,
                    onEdit = { editingTask = it },
                    onFocus = { focusFor = TaskLink(it.id, "fiverr", it.title) }
                )
            } else {
                Column {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = subTab == 0, onClick = { subTab = 0 }, label = { Text("To-do") },
                            leadingIcon = { Icon(Icons.Rounded.TaskAlt, contentDescription = null, modifier = Modifier.size(18.dp)) })
                        FilterChip(selected = subTab == 1, onClick = { subTab = 1 }, label = { Text("Notes") },
                            leadingIcon = { Icon(Icons.Rounded.Description, contentDescription = null, modifier = Modifier.size(18.dp)) })
                    }
                    if (subTab == 0) {
                        TodoTab(vm, onEdit = { editingTodo = it }, onFocus = { focusFor = TaskLink(it.id, "todo", it.title) })
                    } else {
                        NotesTab(vm, onEdit = { editingNote = it })
                    }
                }
            }
            FloatingActionButton(
                onClick = {
                    when {
                        tab == 0 -> editingTask = WorkTask(title = "")
                        subTab == 0 -> editingTodo = TodoItem(title = "", dueEpochDay = LocalDate.now().toEpochDay())
                        else -> editingNote = Note(title = "")
                    }
                },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) { Icon(Icons.Rounded.Add, contentDescription = "Add") }
        }
    }

    editingTask?.let { t ->
        WorkTaskEditor(t, onDismiss = { editingTask = null }, onSave = { vm.saveWorkTask(it); editingTask = null })
    }
    editingTodo?.let { t ->
        TodoEditor(t, onDismiss = { editingTodo = null }, onSave = { vm.saveTodo(it); editingTodo = null }, onDelete = { vm.deleteTodo(it) })
    }
    editingNote?.let { n ->
        NoteEditor(n, onDismiss = { editingNote = null }, onSave = { vm.saveNote(it); editingNote = null }, onDelete = { vm.deleteNote(it) })
    }
    focusFor?.let { link ->
        FocusForTaskDialog(link, onDismiss = { focusFor = null }, onStarted = { focusFor = null; onFocusStarted() })
    }
}

// ------------------------------------------------------------------ Fiverr

@Composable
private fun FiverrTab(vm: AppViewModel, onEdit: (WorkTask) -> Unit, onFocus: (WorkTask) -> Unit) {
    val tasks by vm.workTasks.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val use24h = LocalAppSettings.current.use24h
    var filter by rememberSaveable { mutableIntStateOf(-1) }
    var deleting by remember { mutableStateOf<WorkTask?>(null) }
    val haptic = rememberHaptic()

    val todayStart = startOfToday()
    val todayEnd = todayStart + 86_400_000L
    val workedToday = sessions.filter { it.taskKind == "fiverr" && it.startedAt >= todayStart }.sumOf { it.actualMs }
    val completedToday = tasks.count { it.status == WorkTask.COMPLETED && it.completedAt >= todayStart }
    val inProgress = tasks.count { it.status == WorkTask.IN_PROGRESS }
    val now = System.currentTimeMillis()
    val dueSoon = tasks.count { it.status != WorkTask.COMPLETED && it.deadline in 1 until todayEnd }
    val shown = if (filter < 0) tasks else tasks.filter { it.status == filter }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SectionCard(title = "Today's work summary") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile(formatDuration(workedToday), "Worked", Modifier.weight(1f))
                    StatTile("$inProgress", "Active", Modifier.weight(1f))
                    StatTile("$completedToday", "Delivered", Modifier.weight(1f))
                    StatTile("$dueSoon", "Due today", Modifier.weight(1f), accent = MaterialTheme.colorScheme.tertiary)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Local tracker — not connected to your Fiverr account.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = filter == -1, onClick = { filter = -1 }, label = { Text("All") })
                StatusNames.forEachIndexed { i, n ->
                    FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(n) })
                }
            }
        }
        if (shown.isEmpty()) {
            item { EmptyState(Icons.Rounded.Work, "No orders here", "Tap + to add a client order with its deadline and priority.") }
        }
        items(shown, key = { it.id }) { t ->
            val overdue = t.status != WorkTask.COMPLETED && t.deadline in 1 until now
            Card(
                onClick = { onEdit(t) },
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            t.title,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            textDecoration = if (t.status == WorkTask.COMPLETED) TextDecoration.LineThrough else null
                        )
                        PriorityBadge(t.priority)
                    }
                    val client = listOfNotNull(
                        t.clientName.takeIf { it.isNotBlank() },
                        t.fiverrUsername.takeIf { it.isNotBlank() }?.let { "@" + it.removePrefix("@") }
                    ).joinToString(" · ")
                    if (client.isNotEmpty()) {
                        Text(client, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (t.deadline > 0) {
                            Pill(
                                (if (overdue) "Overdue · " else "Due ") + shortDateTime(t.deadline, use24h),
                                color = if (overdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary
                            )
                        }
                        Pill("Tracked ${formatDuration(t.timeSpentMs)}")
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AssistChip(
                            onClick = {
                                haptic()
                                vm.saveWorkTask(t.copy(status = (t.status + 1) % 3))
                            },
                            label = { Text(StatusNames[t.status.coerceIn(0, 2)]) }
                        )
                        Spacer(Modifier.weight(1f))
                        if (t.status != WorkTask.COMPLETED) {
                            TextButton(onClick = { onFocus(t) }) {
                                Icon(Icons.Rounded.SelfImprovement, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Focus")
                            }
                        }
                        IconButton(onClick = { deleting = t }) { Icon(Icons.Rounded.Delete, contentDescription = "Delete order") }
                    }
                }
            }
        }
    }

    deleting?.let { t ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete \"${t.title}\"?") },
            text = { Text("Tracked time for this order will no longer be shown.") },
            confirmButton = { TextButton(onClick = { vm.deleteWorkTask(t); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun EditorDialog(title: String, onDismiss: () -> Unit, onSave: () -> Unit, saveEnabled: Boolean, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.fillMaxWidth(0.94f).imePadding()
        ) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                content()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(Modifier.width(8.dp))
                    androidx.compose.material3.Button(onClick = onSave, enabled = saveEnabled) { Text("Save") }
                }
            }
        }
    }
}

@Composable
private fun PriorityPicker(priority: Int, onChange: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PriorityNames.forEachIndexed { i, n ->
            FilterChip(selected = priority == i, onClick = { onChange(i) }, label = { Text(n) })
        }
    }
}

@Composable
private fun WorkTaskEditor(initial: WorkTask, onDismiss: () -> Unit, onSave: (WorkTask) -> Unit) {
    val use24h = LocalAppSettings.current.use24h
    var title by remember { mutableStateOf(initial.title) }
    var client by remember { mutableStateOf(initial.clientName) }
    var username by remember { mutableStateOf(initial.fiverrUsername) }
    var deadline by remember { mutableLongStateOf(initial.deadline) }
    var priority by remember { mutableIntStateOf(initial.priority) }
    var status by remember { mutableIntStateOf(initial.status) }
    var notes by remember { mutableStateOf(initial.notes) }
    var pickDate by remember { mutableStateOf(false) }
    var pickTime by remember { mutableStateOf(false) }
    var pendingDay by remember { mutableLongStateOf(0L) }

    EditorDialog(
        title = if (initial.id == 0L) "New Fiverr order" else "Edit order",
        onDismiss = onDismiss,
        saveEnabled = title.isNotBlank(),
        onSave = {
            onSave(
                initial.copy(
                    title = title.trim(), clientName = client.trim(),
                    fiverrUsername = username.trim().removePrefix("@"),
                    deadline = deadline, priority = priority, status = status, notes = notes.trim()
                )
            )
        }
    ) {
        OutlinedTextField(
            value = title, onValueChange = { title = it.take(80) }, label = { Text("Order / task title") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
        )
        OutlinedTextField(
            value = client, onValueChange = { client = it.take(60) }, label = { Text("Client name") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
        )
        OutlinedTextField(
            value = username, onValueChange = { username = it.take(40) }, label = { Text("Fiverr username") },
            prefix = { Text("@") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Text("Deadline", style = MaterialTheme.typography.labelLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { pickDate = true }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Event, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (deadline > 0) shortDateTime(deadline, use24h) else "No deadline")
            }
            if (deadline > 0) TextButton(onClick = { deadline = 0 }) { Text("Clear") }
        }
        Text("Priority", style = MaterialTheme.typography.labelLarge)
        PriorityPicker(priority) { priority = it }
        Text("Status", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusNames.forEachIndexed { i, n ->
                FilterChip(selected = status == i, onClick = { status = i }, label = { Text(n) })
            }
        }
        OutlinedTextField(
            value = notes, onValueChange = { notes = it.take(2000) }, label = { Text("Notes / requirements") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp)
        )
        if (initial.timeSpentMs > 0) {
            Text("Tracked so far: ${formatDuration(initial.timeSpentMs)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (pickDate) {
        val initialDay = if (deadline > 0) Instant.ofEpochMilli(deadline).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay() else 0L
        DatePickerDialogBox(initialDay, onDismiss = { pickDate = false }) { day ->
            pendingDay = day; pickDate = false; pickTime = true
        }
    }
    if (pickTime) {
        val t = if (deadline > 0) Instant.ofEpochMilli(deadline).atZone(ZoneId.systemDefault()).toLocalTime() else LocalTime.of(18, 0)
        TimePickerDialog(t.hour, t.minute, use24h, "Deadline time", onDismiss = { pickTime = false }) { h, m ->
            deadline = LocalDate.ofEpochDay(pendingDay).atTime(h, m).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            pickTime = false
        }
    }
}

// ------------------------------------------------------------------ To-do

@Composable
private fun TodoTab(vm: AppViewModel, onEdit: (TodoItem) -> Unit, onFocus: (TodoItem) -> Unit) {
    val todos by vm.todos.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    // 0 all, 1 today, 2 active, 3 done, 4 high priority
    var filter by rememberSaveable { mutableIntStateOf(2) }
    val haptic = rememberHaptic()
    val today = LocalDate.now().toEpochDay()

    val shown = todos.filter { t ->
        (query.isBlank() || t.title.contains(query, true) || t.details.contains(query, true)) &&
            when (filter) {
                1 -> !t.done && t.dueEpochDay in 1..today
                2 -> !t.done
                3 -> t.done
                4 -> !t.done && t.priority == 2
                else -> true
            }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                placeholder = { Text("Search tasks") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("All", "Due today", "Active", "Done", "High priority").forEachIndexed { i, n ->
                    FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(n) })
                }
            }
        }
        if (shown.isEmpty()) {
            item { EmptyState(Icons.Rounded.TaskAlt, "Nothing here", "Tap + to add a to-do with a priority and due date.") }
        }
        items(shown, key = { it.id }) { t ->
            Card(
                onClick = { onEdit(t) },
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Row(Modifier.padding(start = 4.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { haptic(); vm.saveTodo(t.copy(done = !t.done)) }) {
                        Icon(
                            if (t.done) Icons.Rounded.CheckBox else Icons.Rounded.CheckBoxOutlineBlank,
                            contentDescription = if (t.done) "Mark not done" else "Mark done",
                            tint = if (t.done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            t.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyLarge,
                            textDecoration = if (t.done) TextDecoration.LineThrough else null,
                            color = if (t.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PriorityBadge(t.priority)
                            if (t.dueEpochDay > 0) {
                                val overdue = !t.done && t.dueEpochDay < today
                                Text(
                                    epochDayToLabel(t.dueEpochDay),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (overdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (t.focusMs > 0) {
                                Text("· ${formatDuration(t.focusMs)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (!t.done) {
                        IconButton(onClick = { onFocus(t) }) {
                            Icon(Icons.Rounded.SelfImprovement, contentDescription = "Focus on this task", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TodoEditor(initial: TodoItem, onDismiss: () -> Unit, onSave: (TodoItem) -> Unit, onDelete: (TodoItem) -> Unit) {
    var title by remember { mutableStateOf(initial.title) }
    var details by remember { mutableStateOf(initial.details) }
    var priority by remember { mutableIntStateOf(initial.priority) }
    var due by remember { mutableLongStateOf(initial.dueEpochDay) }
    var pickDate by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    EditorDialog(
        title = if (initial.id == 0L) "New to-do" else "Edit to-do",
        onDismiss = onDismiss,
        saveEnabled = title.isNotBlank(),
        onSave = { onSave(initial.copy(title = title.trim(), details = details.trim(), priority = priority, dueEpochDay = due)) }
    ) {
        OutlinedTextField(
            value = title, onValueChange = { title = it.take(120) }, label = { Text("Task") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
        )
        OutlinedTextField(
            value = details, onValueChange = { details = it.take(2000) }, label = { Text("Details") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp)
        )
        Text("Priority", style = MaterialTheme.typography.labelLarge)
        PriorityPicker(priority) { priority = it }
        Text("Due date", style = MaterialTheme.typography.labelLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { pickDate = true }, modifier = Modifier.weight(1f)) {
                Text(if (due > 0) epochDayToLabel(due) else "No due date")
            }
            if (due > 0) TextButton(onClick = { due = 0 }) { Text("Clear") }
        }
        if (initial.id != 0L) {
            TextButton(onClick = { confirmDelete = true }) {
                Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(6.dp))
                Text("Delete to-do", color = MaterialTheme.colorScheme.error)
            }
        }
    }
    if (pickDate) {
        DatePickerDialogBox(due, onDismiss = { pickDate = false }) { due = it; pickDate = false }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this to-do?") },
            confirmButton = { TextButton(onClick = { onDelete(initial); confirmDelete = false; onDismiss() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

// ------------------------------------------------------------------ Notes

@Composable
private fun NotesTab(vm: AppViewModel, onEdit: (Note) -> Unit) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    val use24h = LocalAppSettings.current.use24h
    val shown = notes.filter { query.isBlank() || it.title.contains(query, true) || it.body.contains(query, true) }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                placeholder = { Text("Search notes") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (shown.isEmpty()) {
            item { EmptyState(Icons.Rounded.Description, "No notes", "Capture ideas, client briefs and checklists. Tap + to start.") }
        }
        items(shown, key = { it.id }) { n ->
            Card(
                onClick = { onEdit(n) },
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            n.title.ifBlank { "Untitled" }, style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        IconButton(onClick = { vm.saveNote(n.copy(pinned = !n.pinned)) }) {
                            Icon(
                                Icons.Rounded.PushPin,
                                contentDescription = if (n.pinned) "Unpin" else "Pin",
                                tint = if (n.pinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                    if (n.body.isNotBlank()) {
                        Text(n.body, maxLines = 4, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Edited ${shortDateTime(n.updatedAt, use24h)}", style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline)
                }
            }
        }
    }
}

@Composable
private fun NoteEditor(initial: Note, onDismiss: () -> Unit, onSave: (Note) -> Unit, onDelete: (Note) -> Unit) {
    var title by remember { mutableStateOf(initial.title) }
    var body by remember { mutableStateOf(initial.body) }
    var confirmDelete by remember { mutableStateOf(false) }

    EditorDialog(
        title = if (initial.id == 0L) "New note" else "Edit note",
        onDismiss = onDismiss,
        saveEnabled = title.isNotBlank() || body.isNotBlank(),
        onSave = { onSave(initial.copy(title = title.trim(), body = body.trimEnd())) }
    ) {
        OutlinedTextField(
            value = title, onValueChange = { title = it.take(120) }, label = { Text("Title") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
        )
        OutlinedTextField(
            value = body, onValueChange = { body = it.take(20_000) }, label = { Text("Note") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
        )
        if (initial.id != 0L) {
            TextButton(onClick = { confirmDelete = true }) {
                Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(6.dp))
                Text("Delete note", color = MaterialTheme.colorScheme.error)
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this note?") },
            confirmButton = { TextButton(onClick = { onDelete(initial); confirmDelete = false; onDismiss() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}
