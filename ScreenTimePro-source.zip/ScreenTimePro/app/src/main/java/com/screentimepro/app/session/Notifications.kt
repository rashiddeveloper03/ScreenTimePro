package com.screentimepro.app.session

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.screentimepro.app.MainActivity
import com.screentimepro.app.R
import com.screentimepro.app.alarm.AlarmReceiver
import com.screentimepro.app.ui.clock.ClockActivity
import com.screentimepro.app.ui.components.formatCountdown
import com.screentimepro.app.ui.components.formatDuration
import com.screentimepro.app.ui.components.timeOfDay

object Notifications {
    const val CH_SESSION = "session_ongoing"
    const val CH_ALERTS = "schedule_alerts"
    const val CH_COMPLETE = "session_complete"

    const val ID_SESSION = 1001
    const val ID_ALERT = 1002
    const val ID_COMPLETE = 1003
    const val ID_MISSED = 1004
    const val ID_BLOCKED = 1005

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val session = NotificationChannel(CH_SESSION, "Active session", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Live countdown while the screen is being kept awake"
            setShowBadge(false)
        }
        val alerts = NotificationChannel(CH_ALERTS, "Schedule alerts", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Turns the screen on and shows the clock when a scheduled session starts"
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val complete = NotificationChannel(CH_COMPLETE, "Session finished", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Tells you when a session ends (sound and vibration follow the in-app settings)"
            setSound(null, null)
            enableVibration(false)
        }
        nm.createNotificationChannels(listOf(session, alerts, complete))
    }

    private fun clockIntent(ctx: Context, requestCode: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, requestCode,
            Intent(ctx, ClockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun mainIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 2,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun action(ctx: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, AlarmReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun sessionNotification(ctx: Context, s: SessionState, remaining: Long, use24h: Boolean): Notification {
        val b = NotificationCompat.Builder(ctx, CH_SESSION)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(s.displayTitle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(clockIntent(ctx, 1))
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)

        when (s.status) {
            SessionStatus.RUNNING -> {
                val endAt = System.currentTimeMillis() + remaining
                b.setUsesChronometer(true)
                    .setChronometerCountDown(true)
                    .setShowWhen(true)
                    .setWhen(endAt)
                    .setContentText("Screen kept awake · ends at ${timeOfDay(endAt, use24h)}")
                    .addAction(0, "Pause", action(ctx, AlarmReceiver.ACTION_PAUSE, 11))
            }
            SessionStatus.PAUSED -> {
                b.setShowWhen(false)
                    .setContentText("Paused · ${formatCountdown(remaining)} left")
                    .addAction(0, "Resume", action(ctx, AlarmReceiver.ACTION_RESUME, 12))
            }
            SessionStatus.IDLE -> b.setContentText("Finishing…")
        }
        b.addAction(0, "Stop", action(ctx, AlarmReceiver.ACTION_STOP, 13))
        return b.build()
    }

    /** High-priority alert with a full-screen intent: turns the display on and shows the clock over the lock screen. */
    fun showScheduleStarted(ctx: Context, s: SessionState) {
        val n = NotificationCompat.Builder(ctx, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle("${s.displayTitle} started")
            .setContentText("Screen on for ${formatDuration(s.totalMs)}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(clockIntent(ctx, 3))
            .setFullScreenIntent(clockIntent(ctx, 4), true)
            .setAutoCancel(true)
            .setTimeoutAfter(60_000)
            .build()
        post(ctx, ID_ALERT, n)
    }

    fun showSessionEnded(ctx: Context, title: String, completed: Boolean, actualMs: Long) {
        val n = NotificationCompat.Builder(ctx, CH_COMPLETE)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(if (completed) "$title complete" else "$title stopped")
            .setContentText("Screen-on time: ${formatDuration(actualMs)}")
            .setContentIntent(mainIntent(ctx))
            .setAutoCancel(true)
            .build()
        post(ctx, ID_COMPLETE, n)
    }

    fun showMissed(ctx: Context, name: String) {
        val n = NotificationCompat.Builder(ctx, CH_COMPLETE)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle("Missed schedule: $name")
            .setContentText("The phone was off or the app was restricted when it was due.")
            .setContentIntent(mainIntent(ctx))
            .setAutoCancel(true)
            .build()
        post(ctx, ID_MISSED, n)
    }

    fun showBlocked(ctx: Context, title: String, reason: String) {
        val n = NotificationCompat.Builder(ctx, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(title)
            .setContentText(reason)
            .setStyle(NotificationCompat.BigTextStyle().bigText(reason))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(mainIntent(ctx))
            .setAutoCancel(true)
            .build()
        post(ctx, ID_BLOCKED, n)
    }

    fun cancel(ctx: Context, id: Int) {
        ctx.getSystemService(NotificationManager::class.java)?.cancel(id)
    }

    fun canPost(ctx: Context): Boolean {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return false
        return nm.areNotificationsEnabled()
    }

    fun canUseFullScreen(ctx: Context): Boolean {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return false
        return if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true
    }

    private fun post(ctx: Context, id: Int, n: Notification) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
            if (nm.areNotificationsEnabled()) nm.notify(id, n)
        } catch (e: SecurityException) {
            Log.w("Notifications", "Notification permission missing", e)
        }
    }
}
