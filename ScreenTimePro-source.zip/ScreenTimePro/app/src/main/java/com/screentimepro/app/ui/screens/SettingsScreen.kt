@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.screentimepro.app.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.screentimepro.app.BuildConfigInfo
import com.screentimepro.app.alarm.AlarmScheduler
import com.screentimepro.app.data.AppSettings
import com.screentimepro.app.data.ThemeMode
import com.screentimepro.app.session.Notifications
import com.screentimepro.app.ui.AppViewModel
import com.screentimepro.app.ui.components.SectionCard
import com.screentimepro.app.ui.components.clockDigits
import com.screentimepro.app.ui.components.rememberNow
import com.screentimepro.app.ui.theme.Accents
import com.screentimepro.app.ui.theme.ClockStyles
import com.screentimepro.app.ui.theme.LocalAppSettings

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val s = LocalAppSettings.current
    val ctx = LocalContext.current
    val update: ((AppSettings) -> AppSettings) -> Unit = { vm.updateSettings(it) }

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val notifOk = remember(tick) { Notifications.canPost(ctx) }
    val exactOk = remember(tick) { AlarmScheduler.canScheduleExact(ctx) }
    val fullScreenOk = remember(tick) { Notifications.canUseFullScreen(ctx) }
    val batteryOk = remember(tick) { isIgnoringBatteryOptimizations(ctx) }
    val batteryLevel = remember(tick) { batteryPercent(ctx) }
    var askBattery by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        tick++
        if (!it) openAppNotificationSettings(ctx)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Settings & permissions") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---------------- Permissions
            SectionCard(title = "Permissions & background") {
                PermissionRow(
                    "Notifications",
                    "Live countdown, session start and finish alerts.",
                    notifOk,
                    "Allow"
                ) {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else openAppNotificationSettings(ctx)
                }
                Divider()
                PermissionRow(
                    "Alarms & reminders (exact alarms)",
                    "Starts schedules on the exact minute. Without it Android may delay them.",
                    exactOk,
                    "Allow"
                ) {
                    if (Build.VERSION.SDK_INT >= 31) {
                        safeStart(ctx, Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
                    }
                }
                Divider()
                PermissionRow(
                    "Full-screen alerts",
                    "Lets a scheduled session turn the display on and show the clock over the lock screen.",
                    fullScreenOk,
                    "Allow"
                ) {
                    if (Build.VERSION.SDK_INT >= 34) {
                        safeStart(ctx, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}")))
                    }
                }
                Divider()
                PermissionRow(
                    "Unrestricted battery",
                    "Stops Android from delaying schedules. Optional - only needed if schedules start late or not at all.",
                    batteryOk,
                    "Allow"
                ) { askBattery = true }
            }

            SectionCard(title = "Vivo / Funtouch OS background settings") {
                Text(
                    "Vivo phones may close background apps aggressively. If schedules don't start:\n" +
                        "1. Settings → Battery → Background power consumption management → ScreenTime Pro → Allow.\n" +
                        "2. Settings → Apps → ScreenTime Pro → Autostart (or i Manager → App manager → Autostart) → On.\n" +
                        "3. Lock the app in Recents (swipe down on its card / tap the lock icon).\n" +
                        "Menu names vary by Funtouch OS version.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                FilledTonalButton(onClick = { openAppDetails(ctx) }) { Text("Open app settings") }
            }

            SectionCard(title = "What Android allows") {
                Text(
                    "• At schedule time the app turns the display on and shows the clock over the lock screen. " +
                        "It cannot unlock a PIN, pattern or fingerprint lock — that's an Android security rule.\n" +
                        "• The screen stays on during a session, but the power button always turns it off.\n" +
                        "• If the phone is switched off at the scheduled time, the session starts (for the remaining time) once the phone is back on.\n" +
                        "• No root, hidden APIs, or system-setting changes are used.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // ---------------- Appearance
            SectionCard(title = "Appearance") {
                Label("Theme")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ThemeMode.SYSTEM to "System", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark", ThemeMode.AMOLED to "AMOLED black").forEach { (m, n) ->
                        FilterChip(selected = s.themeMode == m, onClick = { update { it.copy(themeMode = m) } }, label = { Text(n) })
                    }
                }
                Spacer(Modifier.height(12.dp))
                Label("Accent color")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Accents.forEachIndexed { i, a ->
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(a.color)
                                .then(
                                    if (s.accent == i) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                    else Modifier
                                )
                                .clickable { update { it.copy(accent = i) } },
                            contentAlignment = Alignment.Center
                        ) {
                            if (s.accent == i) Icon(Icons.Rounded.Check, contentDescription = "${a.name} selected", tint = Color.Black.copy(alpha = 0.7f))
                        }
                    }
                }
            }

            SectionCard(title = "Clock") {
                val now = rememberNow()
                val style = ClockStyles[s.clockFont.coerceIn(0, ClockStyles.lastIndex)]
                Text(
                    clockDigits(now, s.use24h, s.showSeconds),
                    fontFamily = style.family,
                    fontWeight = style.weight,
                    fontSize = (40 * s.clockScale).sp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
                Label("Style")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ClockStyles.forEachIndexed { i, cs ->
                        FilterChip(selected = s.clockFont == i, onClick = { update { it.copy(clockFont = i) } }, label = { Text(cs.name) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Label("Full-screen clock size: ${(s.clockScale * 100).toInt()}%")
                var scale by remember(s.clockScale) { mutableFloatStateOf(s.clockScale) }
                Slider(
                    value = scale,
                    onValueChange = { scale = it },
                    onValueChangeFinished = { update { it.copy(clockScale = scale) } },
                    valueRange = 0.6f..1.4f,
                    steps = 7
                )
                SwitchRow("24-hour format", null, s.use24h) { v -> update { it.copy(use24h = v) } }
                SwitchRow("Show seconds", null, s.showSeconds) { v -> update { it.copy(showSeconds = v) } }
                SwitchRow("Dim full-screen clock", "Lowers brightness and contrast — good at night and for battery.", s.dimClock) { v -> update { it.copy(dimClock = v) } }
                SwitchRow("Burn-in protection", "Moves the clock a few pixels every minute on AMOLED screens.", s.burnInShift) { v -> update { it.copy(burnInShift = v) } }
            }

            // ---------------- Display & battery
            SectionCard(title = "Display & battery") {
                SwitchRow(
                    "Keep screen on outside the app",
                    "During a session, keep the display awake even when you switch to other apps.",
                    s.keepScreenOnOutsideApp
                ) { v -> update { it.copy(keepScreenOnOutsideApp = v) } }
                SwitchRow(
                    "Custom in-app brightness",
                    "Only affects ScreenTime Pro's own screens. System brightness is not changed.",
                    s.brightness >= 0f
                ) { v -> update { it.copy(brightness = if (v) 0.5f else -1f) } }
                if (s.brightness >= 0f) {
                    var level by remember(s.brightness) { mutableFloatStateOf(s.brightness) }
                    Slider(
                        value = level,
                        onValueChange = { level = it },
                        onValueChangeFinished = { update { it.copy(brightness = level) } },
                        valueRange = 0.02f..1f
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Battery ${if (batteryLevel >= 0) "$batteryLevel%" else "level unknown"}. Keeping the screen on is the main battery cost — " +
                        "roughly what watching a static page uses. Use AMOLED black + dim clock for long sessions; " +
                        "the app itself stays idle between second ticks and uses no network.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // ---------------- Feedback
            SectionCard(title = "Sound, vibration & notifications") {
                SwitchRow("Completion sound", "Plays your default notification sound when a session ends.", s.sound) { v -> update { it.copy(sound = v) } }
                SwitchRow("Vibration", null, s.vibration) { v -> update { it.copy(vibration = v) } }
                SwitchRow("Haptic feedback on buttons", null, s.haptics) { v -> update { it.copy(haptics = v) } }
                SwitchRow("Session start/finish notifications", "The live countdown notification is always shown while a session runs.", s.notifications) { v -> update { it.copy(notifications = v) } }
            }

            SectionCard(title = "Focus") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Daily goal (sessions)", modifier = Modifier.weight(1f))
                    FilledTonalIconButton(onClick = { update { it.copy(focusGoal = (it.focusGoal - 1).coerceAtLeast(1)) } }) {
                        Icon(Icons.Rounded.Remove, contentDescription = "Decrease goal")
                    }
                    Text("${s.focusGoal}", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 12.dp))
                    FilledTonalIconButton(onClick = { update { it.copy(focusGoal = (it.focusGoal + 1).coerceAtMost(20)) } }) {
                        Icon(Icons.Rounded.Add, contentDescription = "Increase goal")
                    }
                }
            }

            SectionCard(title = "About") {
                Text("ScreenTime Pro ${BuildConfigInfo.versionName(ctx)}", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "All data stays on this phone. Not affiliated with, endorsed by, or connected to Fiverr or Notion.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.rescheduleAll() }) { Text("Re-arm all schedules") }
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    if (askBattery) {
        AlertDialog(
            onDismissRequest = { askBattery = false },
            title = { Text("Allow unrestricted battery?") },
            text = {
                Text(
                    "Android will ask you to let ScreenTime Pro ignore battery optimization. This helps scheduled sessions " +
                        "start on time on Vivo phones. The app does no background work between schedules, so the battery impact is minimal. " +
                        "You can change this later in system settings."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    askBattery = false
                    requestIgnoreBatteryOptimizations(ctx)
                }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { askBattery = false }) { Text("Not now") } }
        )
    }
}

@Composable
private fun Divider() = HorizontalDivider(Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant)

@Composable
private fun Label(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
private fun PermissionRow(title: String, desc: String, granted: Boolean, action: String, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
        Icon(
            if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
            contentDescription = if (granted) "Granted" else "Not granted",
            tint = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!granted) {
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = onClick) { Text(action) }
        }
    }
}

@Composable
private fun SwitchRow(title: String, desc: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 8.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (desc != null) Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun safeStart(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        openAppDetails(ctx)
    }
}

private fun openAppDetails(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
    }
}

private fun openAppNotificationSettings(ctx: Context) {
    safeStart(ctx, Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
}

private fun isIgnoringBatteryOptimizations(ctx: Context): Boolean {
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    return pm.isIgnoringBatteryOptimizations(ctx.packageName)
}

@SuppressLint("BatteryLife")
private fun requestIgnoreBatteryOptimizations(ctx: Context) {
    safeStart(ctx, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
}

private fun batteryPercent(ctx: Context): Int {
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return -1
    val v = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    return if (v in 0..100) v else -1
}
