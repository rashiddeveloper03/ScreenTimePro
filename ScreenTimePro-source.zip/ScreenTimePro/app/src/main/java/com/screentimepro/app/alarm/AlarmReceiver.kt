package com.screentimepro.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.screentimepro.app.session.SessionManager
import com.screentimepro.app.session.SessionStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Schedule alarms, the session-end backup alarm, and notification action buttons. */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val ctx = context.applicationContext
        when (intent.action) {
            AlarmScheduler.ACTION_SCHEDULE_START -> {
                val id = intent.getLongExtra(AlarmScheduler.EXTRA_SCHEDULE_ID, 0)
                val occurrence = intent.getLongExtra(AlarmScheduler.EXTRA_OCCURRENCE, 0)
                val pending = goAsync()
                CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                    try {
                        AlarmScheduler.onScheduleAlarm(ctx, id, occurrence)
                    } catch (e: Exception) {
                        Log.e("AlarmReceiver", "Schedule start failed", e)
                    } finally {
                        pending.finish()
                    }
                }
            }
            AlarmScheduler.ACTION_SESSION_END -> {
                val s = SessionManager.state.value
                if (s.status == SessionStatus.RUNNING) {
                    if (SessionManager.remainingMs(s) <= 1_500) SessionManager.complete()
                    else SessionManager.reanchor() // fired early (clock change): re-arm for the real end
                }
            }
            ACTION_PAUSE -> SessionManager.pause()
            ACTION_RESUME -> SessionManager.resume()
            ACTION_STOP -> SessionManager.stop()
        }
    }

    companion object {
        const val ACTION_PAUSE = "com.screentimepro.app.action.PAUSE"
        const val ACTION_RESUME = "com.screentimepro.app.action.RESUME"
        const val ACTION_STOP = "com.screentimepro.app.action.STOP"
    }
}
