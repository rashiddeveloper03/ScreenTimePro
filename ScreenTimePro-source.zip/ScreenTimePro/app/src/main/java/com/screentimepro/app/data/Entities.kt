package com.screentimepro.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A scheduled screen-on window.
 * repeatDays is a bitmask: bit 0 = Monday ... bit 6 = Sunday. 0 means a one-time schedule on [oneTimeEpochDay].
 */
@Entity(tableName = "schedules")
data class Schedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val startHour: Int,
    val startMinute: Int,
    val durationMinutes: Int,
    val repeatDays: Int = 0,
    val oneTimeEpochDay: Long = 0,
    val enabled: Boolean = true,
    val wakeScreen: Boolean = true,
    /** Epoch millis of the occurrence that was last started; prevents duplicate starts. */
    val lastTriggeredStart: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val EVERY_DAY = 0b1111111
        const val WEEKDAYS = 0b0011111
        const val WEEKEND = 0b1100000
    }
}

/** Not a column: derived from [Schedule.repeatDays]. */
val Schedule.isOneTime: Boolean get() = repeatDays == 0

@Entity(tableName = "session_records")
data class SessionRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** TIMER, FOCUS or SCHEDULE */
    val type: String,
    val label: String,
    val startedAt: Long,
    val endedAt: Long,
    val plannedMs: Long,
    val actualMs: Long,
    val completed: Boolean,
    val taskId: Long = 0,
    /** "fiverr", "todo" or "" */
    val taskKind: String = ""
)

/** Fiverr client order tracked locally. Not connected to Fiverr's servers. */
@Entity(tableName = "work_tasks")
data class WorkTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val clientName: String = "",
    val fiverrUsername: String = "",
    /** Epoch millis, 0 = no deadline */
    val deadline: Long = 0,
    /** 0 low, 1 medium, 2 high */
    val priority: Int = 1,
    /** 0 pending, 1 in progress, 2 completed */
    val status: Int = 0,
    val timeSpentMs: Long = 0,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long = 0
) {
    companion object {
        const val PENDING = 0
        const val IN_PROGRESS = 1
        const val COMPLETED = 2
    }
}

@Entity(tableName = "todos")
data class TodoItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val details: String = "",
    /** 0 low, 1 medium, 2 high */
    val priority: Int = 1,
    /** Epoch day, 0 = no due date */
    val dueEpochDay: Long = 0,
    val done: Boolean = false,
    val focusMs: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String = "",
    val pinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
