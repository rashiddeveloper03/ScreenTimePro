package com.screentimepro.app.session

import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.screentimepro.app.ScreenTimeApp
import com.screentimepro.app.data.AppSettings
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground service that exists only while a session is active. It:
 *  - shows the ongoing countdown notification,
 *  - holds a screen wake lock so the display stays on even outside the app (user setting),
 *  - ends the session exactly when the countdown reaches zero,
 *  - turns the display on at the start of a scheduled session (full-screen intent + wake-up lock).
 */
class SessionService : LifecycleService() {

    private var keepOnLock: PowerManager.WakeLock? = null
    private var loopJob: Job? = null
    private var settingsJob: Job? = null
    private var lastShown: SessionState? = null
    private var settings = AppSettings()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val s = SessionManager.state.value
        goForeground(s)
        if (!s.isActive) {
            shutdown()
            return START_NOT_STICKY
        }
        if (intent?.getBooleanExtra(EXTRA_WAKE, false) == true) wakeScreen(s)
        lastShown = null
        if (settingsJob == null) {
            settingsJob = lifecycleScope.launch {
                (application as ScreenTimeApp).settings.flow.collect {
                    settings = it
                    lastShown = null
                }
            }
        }
        if (loopJob?.isActive != true) {
            loopJob = lifecycleScope.launch { loop() }
        }
        return START_STICKY
    }

    private suspend fun loop() {
        while (currentCoroutineContext().isActive) {
            val s = SessionManager.state.value
            if (!s.isActive) {
                shutdown()
                return
            }
            if (s.status == SessionStatus.RUNNING && SessionManager.remainingMs(s) <= 0) {
                SessionManager.complete()
                continue
            }
            if (s != lastShown) {
                updateNotification(s)
                updateKeepOnLock(s)
                lastShown = s
            }
            val rem = SessionManager.remainingMs(s)
            delay(if (s.status == SessionStatus.RUNNING) rem.coerceIn(50L, 1000L) else 1000L)
        }
    }

    private fun goForeground(s: SessionState) {
        val n = Notifications.sessionNotification(this, s, SessionManager.remainingMs(s), settings.use24h)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(this, Notifications.ID_SESSION, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(Notifications.ID_SESSION, n)
            }
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
        }
    }

    private fun updateNotification(s: SessionState) {
        val n = Notifications.sessionNotification(this, s, SessionManager.remainingMs(s), settings.use24h)
        try {
            getSystemService(android.app.NotificationManager::class.java)?.notify(Notifications.ID_SESSION, n)
        } catch (e: SecurityException) {
            Log.w(TAG, "notify failed", e)
        }
    }

    @Suppress("DEPRECATION")
    private fun updateKeepOnLock(s: SessionState) {
        val shouldHold = s.status == SessionStatus.RUNNING && settings.keepScreenOnOutsideApp
        keepOnLock?.let { if (it.isHeld) it.release() }
        keepOnLock = null
        if (shouldHold) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            // SCREEN_BRIGHT_WAKE_LOCK is deprecated in favour of FLAG_KEEP_SCREEN_ON, which only works
            // while our window is visible. This lock is what keeps the display on over other apps.
            // The power button still turns the screen off - Android does not allow apps to block that.
            keepOnLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ON_AFTER_RELEASE,
                "ScreenTimePro:keepOn"
            ).apply {
                setReferenceCounted(false)
                acquire(SessionManager.remainingMs(s) + 5_000L)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen(s: SessionState) {
        Notifications.showScheduleStarted(this, s)
        runCatching {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "ScreenTimePro:wakeUp"
            ).apply {
                setReferenceCounted(false)
                acquire(15_000L)
            }
        }
    }

    private fun shutdown() {
        keepOnLock?.let { if (it.isHeld) it.release() }
        keepOnLock = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        keepOnLock?.let { if (it.isHeld) it.release() }
        keepOnLock = null
        loopJob = null
        settingsJob = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "SessionService"
        private const val EXTRA_WAKE = "wake"

        fun start(ctx: Context, wake: Boolean = false) {
            val i = Intent(ctx, SessionService::class.java).putExtra(EXTRA_WAKE, wake)
            try {
                ContextCompat.startForegroundService(ctx, i)
            } catch (e: Exception) {
                // Android 12+ blocks starting a foreground service from the background in some cases
                // (e.g. inexact alarm fallback). The session state is still saved and the countdown
                // remains correct; tell the user so they can open the app.
                Log.w(TAG, "Could not start session service", e)
                Notifications.showBlocked(
                    ctx,
                    "Session running - open ScreenTime Pro",
                    "Android didn't allow the app to keep the screen awake from the background. " +
                        "Tap to open the app, and allow exact alarms and unrestricted battery in Settings."
                )
            }
        }
    }
}
