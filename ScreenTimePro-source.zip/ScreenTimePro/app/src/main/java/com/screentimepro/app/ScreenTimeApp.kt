package com.screentimepro.app

import android.app.Application
import com.screentimepro.app.alarm.AlarmScheduler
import com.screentimepro.app.data.AppDatabase
import com.screentimepro.app.data.SettingsRepository
import com.screentimepro.app.session.Notifications
import com.screentimepro.app.session.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ScreenTimeApp : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var database: AppDatabase
        private set
    lateinit var settings: SettingsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = AppDatabase.build(this)
        settings = SettingsRepository(this)
        Notifications.createChannels(this)
        SessionManager.init(this)
        // Re-arm every enabled schedule. PendingIntents use one stable request code per
        // schedule, so this replaces existing alarms instead of duplicating them.
        appScope.launch(Dispatchers.IO) {
            AlarmScheduler.rescheduleAll(this@ScreenTimeApp)
        }
    }

    companion object {
        lateinit var instance: ScreenTimeApp
            private set
    }
}
