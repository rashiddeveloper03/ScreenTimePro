package com.screentimepro.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.screentimepro.app.MainActivity
import com.screentimepro.app.ScreenTimeApp
import com.screentimepro.app.data.Schedule
import com.screentimepro.app.data.isOneTime
import com.screentimepro.app.session.Notifications
import com.screentimepro.app.session.SessionManager
import com.screentimepro.app.session.SessionType
import java.time.ZonedDateTime

object AlarmScheduler {
    private const val TAG = "AlarmScheduler"
    const val ACTION_SCHEDULE_START = "com.screentimepro.app.action.SCHEDULE_START"
    const val ACTION_SESSION_END = "com.screentimepro.app.action.SESSION_END"
    const val EXTRA_SCHEDULE_ID = "schedule_id"
    const val EXTRA_OCCURRENCE = "occurrence"

    private const val REQ_SCHEDULE_BASE = 10_000
    private const val REQ_SESSION_END = 9_001

    fun canScheduleExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return false
        return am.canScheduleExactAlarms()
    }

    private fun requestCode(id: Long): Int = REQ_SCHEDULE_BASE + (id % 1_000_000L).toInt()

    private fun startIntent(ctx: Context, id: Long, occurrence: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, requestCode(id),
            Intent(ctx, AlarmReceiver::class.java)
                .setAction(ACTION_SCHEDULE_START)
                .putExtra(EXTRA_SCHEDULE_ID, id)
                .putExtra(EXTRA_OCCURRENCE, occurrence),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun endIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, REQ_SESSION_END,
            Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_SESSION_END),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun showIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 7,
            Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** Arms (or re-arms) one schedule. Same request code per schedule => never duplicated. */
    fun scheduleOne(ctx: Context, s: Schedule, now: ZonedDateTime = ZonedDateTime.now()) {
        cancel(ctx, s.id)
        if (!s.enabled) return
        val next = ScheduleCalc.nextStart(s, now) ?: return
        val at = next.toInstant().toEpochMilli()
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = startIntent(ctx, s.id, at)
        try {
            if (canScheduleExact(ctx)) {
                // setAlarmClock is exact, fires in Doze, and lets us start the foreground service.
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, showIntent(ctx)), pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Exact alarm denied, using inexact", e)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(startIntent(ctx, id, 0))
    }

    /** Backup alarm that ends the session even if the service was killed. */
    fun setSessionEndBackup(ctx: Context, endWall: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        try {
            if (canScheduleExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endWall, endIntent(ctx))
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endWall, endIntent(ctx))
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endWall, endIntent(ctx))
        }
    }

    fun cancelSessionEndBackup(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java)?.cancel(endIntent(ctx))
    }

    /**
     * Called on app start, boot, time / time-zone change and exact-alarm permission change.
     * - re-arms every enabled schedule,
     * - starts a session for any schedule whose window is in progress but was missed
     *   (phone off, app killed by the system), with only the remaining time,
     * - disables finished one-time schedules and reports ones that never ran.
     */
    suspend fun rescheduleAll(ctx: Context) {
        val app = ctx.applicationContext as ScreenTimeApp
        val dao = app.database.scheduleDao()
        val now = ZonedDateTime.now()
        val nowMs = now.toInstant().toEpochMilli()
        for (s in dao.getAll()) {
            if (!s.enabled) {
                cancel(ctx, s.id)
                continue
            }
            var current = s
            val window = ScheduleCalc.activeWindowStart(s, now)
            if (window != null && s.lastTriggeredStart != window) {
                current = startOccurrence(ctx, s, window, nowMs)
                dao.save(current)
            } else if (s.isOneTime && window == null && ScheduleCalc.nextStart(s, now) == null) {
                if (s.lastTriggeredStart == 0L) Notifications.showMissed(ctx, s.name)
                current = s.copy(enabled = false)
                dao.save(current)
            }
            scheduleOne(ctx, current, now)
        }
    }

    /** Alarm fired for [scheduleId]. */
    suspend fun onScheduleAlarm(ctx: Context, scheduleId: Long, occurrence: Long) {
        val app = ctx.applicationContext as ScreenTimeApp
        val dao = app.database.scheduleDao()
        val s = dao.getById(scheduleId) ?: return
        val now = ZonedDateTime.now()
        val nowMs = now.toInstant().toEpochMilli()
        if (!s.enabled) return
        val occ = when {
            occurrence > 0 && nowMs >= occurrence - 60_000 -> occurrence
            else -> ScheduleCalc.activeWindowStart(s, now)
        }
        if (occ == null || s.lastTriggeredStart == occ) {
            scheduleOne(ctx, s, now)
            return
        }
        val updated = startOccurrence(ctx, s, occ, nowMs)
        dao.save(updated)
        scheduleOne(ctx, updated, now)
    }

    private fun startOccurrence(ctx: Context, s: Schedule, occurrenceStart: Long, nowMs: Long): Schedule {
        val endAt = occurrenceStart + s.durationMinutes * 60_000L
        val startFrom = maxOf(nowMs, occurrenceStart)
        val remaining = endAt - startFrom
        if (remaining > 5_000) {
            val active = SessionManager.state.value
            if (active.isActive && active.scheduleId != s.id) {
                Notifications.showBlocked(
                    ctx,
                    "Schedule \"${s.name}\" skipped",
                    "Another session (${active.displayTitle}) was already running."
                )
            } else {
                SessionManager.start(
                    type = SessionType.SCHEDULE,
                    durationMs = remaining,
                    label = s.name,
                    scheduleId = s.id,
                    wakeScreen = s.wakeScreen
                )
            }
        }
        var updated = s.copy(lastTriggeredStart = occurrenceStart)
        if (s.isOneTime) updated = updated.copy(enabled = false)
        return updated
    }
}
