package com.screentimepro.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.screentimepro.app.data.AppSettings
import com.screentimepro.app.data.ThemeMode

data class Accent(val name: String, val color: Color)

val Accents = listOf(
    Accent("Violet", Color(0xFF8B7CFF)),
    Accent("Teal", Color(0xFF2DD4BF)),
    Accent("Amber", Color(0xFFF5A524)),
    Accent("Rose", Color(0xFFFB6F92)),
    Accent("Emerald", Color(0xFF34D399)),
    Accent("Sky", Color(0xFF38BDF8))
)

data class ClockStyle(val name: String, val family: FontFamily, val weight: FontWeight)

val ClockStyles = listOf(
    ClockStyle("Classic", FontFamily.SansSerif, FontWeight.Medium),
    ClockStyle("Mono", FontFamily.Monospace, FontWeight.Normal),
    ClockStyle("Serif", FontFamily.Serif, FontWeight.Normal),
    ClockStyle("Thin", FontFamily.SansSerif, FontWeight.Thin)
)

fun clockStyle(index: Int): ClockStyle = ClockStyles[index.coerceIn(0, ClockStyles.lastIndex)]

val LocalAppSettings = compositionLocalOf { AppSettings() }
val LocalIsDark = compositionLocalOf { true }

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

private val AppTypography = Typography().let { t ->
    t.copy(
        headlineLarge = t.headlineLarge.copy(fontWeight = FontWeight.SemiBold),
        headlineMedium = t.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = t.labelLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp)
    )
}

val TimerDigits = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light, letterSpacing = 1.sp)

@Composable
fun ScreenTimeTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK, ThemeMode.AMOLED -> true
    }
    val amoled = settings.themeMode == ThemeMode.AMOLED
    val accent = Accents[settings.accent.coerceIn(0, Accents.lastIndex)].color
    val onAccent = if (accent.luminance() > 0.45f) Color(0xFF111018) else Color.White

    val scheme = if (dark) {
        val bg = if (amoled) Color.Black else Color(0xFF0E0F16)
        val s1 = if (amoled) Color(0xFF0A0A0D) else Color(0xFF151622)
        val s2 = if (amoled) Color(0xFF121216) else Color(0xFF1B1C2B)
        val s3 = if (amoled) Color(0xFF1A1A20) else Color(0xFF232436)
        darkColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = accent.copy(alpha = 0.22f).compositeOver(bg),
            onPrimaryContainer = Color.White,
            secondary = accent,
            onSecondary = onAccent,
            secondaryContainer = accent.copy(alpha = 0.16f).compositeOver(s2),
            onSecondaryContainer = Color.White,
            tertiary = Color(0xFFFFB86B),
            background = bg,
            onBackground = Color(0xFFECECF4),
            surface = bg,
            onSurface = Color(0xFFECECF4),
            surfaceVariant = s2,
            onSurfaceVariant = Color(0xFFA3A4B8),
            surfaceContainerLowest = bg,
            surfaceContainerLow = s1,
            surfaceContainer = s1,
            surfaceContainerHigh = s2,
            surfaceContainerHighest = s3,
            outline = Color(0xFF3A3B52),
            outlineVariant = Color(0xFF2A2B3D),
            error = Color(0xFFFF6B7A)
        )
    } else {
        val bg = Color(0xFFF6F6FB)
        lightColorScheme(
            primary = accent.copy(red = accent.red * 0.82f, green = accent.green * 0.82f, blue = accent.blue * 0.82f),
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.18f).compositeOver(Color.White),
            onPrimaryContainer = Color(0xFF15142A),
            secondary = accent,
            secondaryContainer = accent.copy(alpha = 0.14f).compositeOver(Color.White),
            onSecondaryContainer = Color(0xFF15142A),
            tertiary = Color(0xFFB45309),
            background = bg,
            onBackground = Color(0xFF15142A),
            surface = bg,
            onSurface = Color(0xFF15142A),
            surfaceVariant = Color(0xFFE9E9F2),
            onSurfaceVariant = Color(0xFF5B5C70),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = Color.White,
            surfaceContainer = Color(0xFFF0F0F7),
            surfaceContainerHigh = Color.White,
            surfaceContainerHighest = Color.White,
            outline = Color(0xFFCACAD8),
            outlineVariant = Color(0xFFE2E2EC),
            error = Color(0xFFD92D45)
        )
    }

    androidx.compose.runtime.CompositionLocalProvider(
        LocalAppSettings provides settings,
        LocalIsDark provides dark
    ) {
        MaterialTheme(colorScheme = scheme, typography = AppTypography, shapes = AppShapes, content = content)
    }
}
