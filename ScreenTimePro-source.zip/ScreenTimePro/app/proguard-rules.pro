# Room, Compose, DataStore and Navigation ship their own consumer rules.
# Keep Room entities' field names stable for safety.
-keep class com.screentimepro.app.data.** { *; }
