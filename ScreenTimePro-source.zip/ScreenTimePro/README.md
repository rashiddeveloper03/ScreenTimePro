# ScreenTime Pro — Smart Screen & Focus Timer

Native Android app (Kotlin, Jetpack Compose, Material 3) for the Vivo Y29 (Android 14 / Funtouch OS). Works on Android 8.0+.

## Build status (be aware)

This project was written in an environment that could not download the Android SDK or Gradle/Maven
dependencies, so **the APK has not been compiled yet** and on-device tests have not been run.
The pure logic (schedule calculation, time-zone handling, countdown/duration formatting) was compiled
with Kotlin 2.1.20 and its 12 unit tests passed. Every Kotlin file was parsed without syntax errors.
The first real Gradle build may surface a few compile errors to fix.

## Get the APK

### Option A — GitHub Actions (no PC needed)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab → **Build APK** → it runs automatically on push (or press *Run workflow*).
3. When it finishes, download **ScreenTimePro-debug-apk** from the run's *Artifacts* section and unzip it.

### Option B — Android Studio
1. Open this folder in Android Studio (Ladybug 2024.3 or newer), let Gradle sync.
2. *Build → Build App Bundle(s) / APK(s) → Build APK(s)*, or run `./gradlew assembleDebug`.
3. Output: `app/build/outputs/apk/debug/app-debug.apk`

Release build: `./gradlew assembleRelease` with signing env vars set
(`STP_KEYSTORE`, `STP_KEYSTORE_PASSWORD`, `STP_KEY_ALIAS`, `STP_KEY_PASSWORD`). No keys are stored in the source.

## Install on the Vivo Y29
1. Copy `app-debug.apk` to the phone and tap it. Allow *Install unknown apps* for your file manager when asked.
2. Open ScreenTime Pro → Home shows a red card if anything is missing → tap **Fix** and allow:
   notifications, *Alarms & reminders*, full-screen alerts, and (optional) unrestricted battery.
3. Vivo: Settings → Battery → Background power consumption management → ScreenTime Pro → **Allow**;
   enable **Autostart**; lock the app in Recents.

## Features
- **Smart timer**: quick 5m–12h presets, custom duration, start / pause / resume / restart / stop, auto-end.
- **Schedules**: multiple, one-time / daily / chosen weekdays, duration *or* end time, enable/disable, edit, delete,
  next-session display, survives reboot, time-zone and manual clock changes, no duplicate alarms,
  missed-schedule handling (in-progress windows resume for the remaining time; missed one-time schedules are reported).
- **Screen wake**: full-screen notification turns the display on and shows the clock over the lock screen.
- **Full-screen clock**: large clock, date and weekday, seconds toggle, 12/24h, 4 clock styles, size slider,
  countdown, dim mode, AMOLED burn-in shift; taps only reveal controls, stopping needs a 1.5 s hold.
- **Focus mode**: 25 / 50 / 90 / custom, link to a task, daily goal, stats and history.
- **Fiverr orders**: client name, @username, deadline, priority, status, focus timer, tracked time, daily summary
  (local tracker, not connected to Fiverr).
- **Workspace**: to-dos with priority and due date, search and filters, focus on a to-do, notes with pinning and search.
- **History & stats**: 7-day chart, focus streak, full session log.
- **Settings**: themes (System/Light/Dark/AMOLED), 6 accent colors, in-app-only brightness, sound, vibration,
  haptics, notifications, permission status, Vivo guidance.

## Android limits (honest)
- An app cannot unlock a PIN/pattern/fingerprint lock. At schedule time it turns the screen on and shows the clock
  *over* the lock screen.
- The power button always turns the screen off; no app can block it.
- If the phone is off at the scheduled time, the session starts for the remaining time once it's back on.
- Optional Notion API sync is **not** included (it would need internet permission and your API key); all data is local.

## Architecture
```
data/      Room entities + DAOs, DataStore settings
session/   SessionManager (single active session, persisted, reboot/clock-safe), SessionService (foreground),
           Notifications, Alerts
alarm/     ScheduleCalc (pure, unit-tested), AlarmScheduler, AlarmReceiver, SystemEventReceiver
ui/        Compose screens, components, theme, full-screen ClockActivity
```
